import { React, useEffect, useState } from "react";
import "../components/Dashboard/Dashboard.css";
import axios from "axios";
import Cookies from "universal-cookie";

function List(props) {
  const cookies = new Cookies();
  const Token = cookies.get("Token");
  const [data, setData] = useState([]);
  const [email, setEmail] = useState("");
  //create a new array by filtering the original array
  useEffect(() => {
    const restemail = async () => {
      try {
        const res = await axios.post(
          "http://localhost:2100/api/auth/tokenverify",
          { Token }
        );

        return setEmail(res.data.usercheck.email);
      } catch (error) {
        console.log(error);
      }
    };

    restemail();
    rest();
  }, [Token, email]);

  const rest = async () => {
    try {
      const res = await axios.post("http://localhost:2100/api/auth/allclient", {
        email,
      });

      return setData(res.data.data);
    } catch (error) {
      console.log(error);
    }
  };

  const filteredData = data.filter((el) => {
    //if no input the return the original
    if (props.input !== "" && isNaN(props.input)) {
      console.log(el.clientname.toLowerCase().includes(props.input), "dadad 2");
      return el.clientname.toLowerCase().includes(props.input);
    } else if (!isNaN(props.input)) {
      if (el.tripId.toString().includes(props.input)) {
        return el.tripId.toString().includes(props.input);
      } else {
        console.log(
          el.contactNumber.toString().includes(props.input),
          "number"
        );
        return el.contactNumber.toString().includes(props.input);
      }
    }
  });
  console.log(filteredData, "ok");
  //     Status
  // :
  // "New Lead"
  // adults
  // :
  // 8
  // children
  // :
  // 8
  // clientemail
  // :
  // "checkingstatus@gmail.com"
  // clientname
  // :
  // "checkiing with status"
  // comments
  // :
  // ""
  // contactNumber
  // :
  // 9602675361
  // createdAt
  // :
  // "2023-02-03T11:03:45.504Z"
  // days
  // :
  // 8
  // destination
  // :
  // "noida"
  // startdate
  // :
  // "2023-02-18"
  // tripId
  // :
  // 6341
  // updatedAt
  // :
  // "2023-02-03T11:03:45.504Z"
  // userid
  // :
  // "63c9495bbb28b52ad96fa99d"
  // __v
  // :
  // 0
  // _id
  // :
  // "63dcea11b333f8e833a0068e"

  return (
    <>
      {filteredData.map((item) => (
        <tr key={item.id}>
          <td>{item.tripId}</td>
          <td>{item.clientname}</td>
          <td>{item.contactNumber}</td>
          <td>{item.destination}</td>
          <td>{item.startdate}</td>
          <td>{item.days}</td>
          <td>
            {item.adults + "A • "}
            {item.children + "C"}
          </td>
          <td>{item.Status}</td>
        </tr>
      ))}
    </>

    // <ul>
    //     {filteredData.map((item) => (
    //         <tr>
    //             <td key={item.id}>{item.clientname}</td>
    //             <td key={item.id}>{item.clientemail}</td>
    //             <td key={item.id}>Delivered</td>
    //             <td key={item.id}>okay</td>
    //         </tr>

    //     ))}
    // </ul>
  );
}

export default List;
