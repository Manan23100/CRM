import React, { useContext, useState } from "react";
import "./Login.css";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { UserContext } from "./Usercontext";
import Cookies from "universal-cookie";
import { BiBookBookmark } from "react-icons/bi";
import Navbar from "../components/navbar/Navbar";

const Login = () => {
  const nav = useNavigate();
  const [useremail, setUseremail] = useState("");
  const [password, setPassword] = useState("");

  const { email, setEmail } = useContext(UserContext);

  const handleNum = async (e) => {
    e.preventDefault();
    if (!useremail) {
      console.log("first");
    } else {
      try {
        const res = await axios.post("http://localhost:2100/api/auth/login", {
          email: useremail,
          password,
        });

        const cookies = new Cookies();
        cookies.set("Token", res.data.token, { path: "/" });

        setEmail(res.data.user.email);

        return nav("/dashboard");
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    <>
      {/* <div className="navbars1">
        <BiBookBookmark className="firstLogoo" />
        <div className="navContainered">
          <Link to="/" style={{ color: "inherit", textDecoration: "none" }}>
            <span className="logosss">Holidays Crowd</span>
          </Link>
          <div className="navItemsss">
            <Link to="/home" className="navButtoned">
              Home
            </Link>
            <Link to="/login" className="navButtoned">
              LogIn
            </Link>
            <Link to="/signup" className="navButtoned">
              SignUp
            </Link>
          </div>
        </div>
      </div> */}
      <Navbar />
      {/* <div className="toppered">
        <div className="logo">
          <img
            src="http://holidaycrowd.in/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Flogo.8cbb6f15.png&w=1920&q=75"
            alt="logo"
            className="imged"
          />
        </div>
        <div className="hsced">
          <h1 className="heading">Holidays Crowd</h1>
        </div>
      </div> */}
      <div className="topperss">
        <div className="logintotheapp">
          <div className="logged">
            <h1 className="loginthehc">LogIn to Holidays Crowd</h1>
          </div>
        </div>
        <form className="formedd">
          <div className="uNameddd">
            <div className="unameinnereddd email">
              <label htmlFor="email" className="labeled">
                Email
              </label>
            </div>
            <div className="inputit">
              <input
                onChange={(e) => {
                  setUseremail(e.target.value);
                }}
                type="text"
                className="input1ii"
                placeholder="enter Username here"
              />
            </div>
          </div>
          <div className="uNameddd">
            <div className="unameinnereddd pass">
              <label htmlFor="email" className="labeled">
                Password
              </label>
            </div>
            <div className="inputit">
              <input
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                value={password}
                type="password"
                className="input1ii"
                placeholder="enter password here"
              />
            </div>
          </div>
          <Link to="/forgetpassword" className="frgtLinkkked">
            Forget Password?
          </Link>
          <Link to="/Signup" className="frgtLinkkked">
            New Account (SignUp here)
          </Link>
          <div className="signBtn">
            <button className="btned" onClick={handleNum}>
              LogIn
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default Login;
