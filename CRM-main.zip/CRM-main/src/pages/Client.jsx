import React, { useEffect, useState } from "react";
import "./Client.css";
import axios from "axios";
import { AiFillCloseSquare } from "react-icons/ai";
import Cookies from "universal-cookie";
// import { useNavigate } from "react-router-dom";
import DatePicker from "react-datepicker";

const Client = ({ pop, setPop }) => {
  // const nav = useNavigate();
  const [email, setEmail] = useState("");

  const [clientDetails, setClientDetails] = useState({
    clientname: "",
    clientemail: "",
    contactNumber: "",
    destination: "",
    startDate: new Date(),
    days: "",
    adults: "",
    children: "",
    comments: "",
  });

  console.log(clientDetails);

  const cookies = new Cookies();
  const Token = cookies.get("Token");
  useEffect(() => {
    const restemail = async () => {
      try {
        const res = await axios.post(
          "http://localhost:2100/api/auth/tokenverify",
          { Token }
        );
        return setEmail(res.data.usercheck.email);
      } catch (error) {
        console.log(error);
      }
    };

    restemail();
  }, [Token, email]);
  const handleNum = async (e) => {
    e.preventDefault();
    if (!clientDetails.clientname) {
      console.log("first");
    } else {
      try {
        // const email1 = sessionStorage.getItem("datakey");
        // const email = email1.replace(/^"(.+(?="$))"$/, "$1");
        const res = await axios.post(
          "http://localhost:2100/api/client/addClient",
          {
            email,
            clientDetails,
          }
        );
       return window.location.reload(true);
        return setPop(!pop);
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    <>
      <div className="top1">
        <div className="top">
          <div
            onClick={() => {
              setPop(false);
            }}
            className="closeBtn"
          >
            <AiFillCloseSquare />
          </div>
          <div className="loginto">
            <div className="logged">
              <h1 className="login">New Client Registation Form</h1>
            </div>
          </div>
          <form className="form">
            <div className="firstF">
              <div className="uName">
                <div className="unameinner name">
                  <label htmlFor="email" className="label1">
                    Client Name
                  </label>
                </div>
                <div className="input1">
                  <input
                    value={clientDetails.clientname}
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    type="text"
                    id="clientname"
                    className="input1i"
                    placeholder="enter your name"
                  />
                </div>
              </div>
              <div className="uName">
                <div className="unameinner pass cemail">
                  <label htmlFor="email" className="label1 lb1">
                    Client Email
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.clientemail}
                    type="email"
                    id="clientemail"
                    className="input1i"
                    placeholder="enter email here"
                  />
                </div>
              </div>
            </div>
            <div className="secondF">
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    Contact Number
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.contactNumber}
                    type="tel"
                    id="contactNumber"
                    className="input1i"
                    placeholder="enter contact number here"
                  />
                </div>
              </div>
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    Destination
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.destination}
                    type="text"
                    id="destination"
                    className="input1i"
                    placeholder="enter destination here"
                  />
                </div>
              </div>
            </div>
            <div className="thirdF">
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    Start Date
                  </label>
                </div>
                <div className="input1">
                  <DatePicker
                    selected={clientDetails.startDate}
                    id="startDate"
                    className="fnamee"
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        startDate: e,
                      }))
                    }
                  />
                </div>
              </div>
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    No. of days
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.days}
                    id="days"
                    type="number"
                    className="input1i"
                    placeholder="enter days here"
                  />
                </div>
              </div>
            </div>
            <div className="forthF">
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    Number of Adults
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.adults}
                    type="text"
                    id="adults"
                    className="input1i"
                    placeholder="adults count"
                  />
                </div>
              </div>
              <div className="uName">
                <div className="unameinner pass">
                  <label htmlFor="email" className="label1">
                    Number of Children
                  </label>
                </div>
                <div className="input1">
                  <input
                    onChange={(e) =>
                      setClientDetails((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                    value={clientDetails.children}
                    type="text"
                    id="children"
                    className="input1i"
                    placeholder="children count"
                  />
                </div>
              </div>
            </div>
            <div className="uName">
              <div className="unameinner pass">
                <label htmlFor="email" className="label1">
                  Comments (optional)
                </label>
              </div>
              <div className="input1">
                <textarea
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.comments}
                  type="text"
                  id="comments"
                  className="input1i tarea"
                  placeholder="enter your comments here"
                />
              </div>
            </div>
            <div className="signBtn">
              <button className="btn" onClick={handleNum}>
                Add Client
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* for 768 responsive */}

      <div className="top1m">
        <div className="topm">
          <div
            onClick={() => {
              setPop(false);
            }}
            className="closeBtnm"
          >
            <AiFillCloseSquare />
          </div>
          <div className="logintom">
            <div className="loggedm">
              <h1 className="loginm">New Client Registation Form</h1>
            </div>
          </div>
          <form className="formm">
            <div className="uNamem">
              <div className="unameinnerm namem">
                <label htmlFor="emailm" className="label1m">
                  Client Name
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.clientname}
                  type="text"
                  id="clientname"
                  className="input1im"
                  placeholder="enter your name"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm cemailm">
                <label htmlFor="email" className="label1m lb1m">
                  Client Email
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.clientemail}
                  type="email"
                  id="clientemail"
                  className="input1im"
                  placeholder="enter email here"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Contact Number
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.contactNumber}
                  type="tel"
                  id="contactNumber"
                  className="input1im"
                  placeholder="enter contact number here"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Destination
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.destination}
                  type="text"
                  id="destination"
                  className="input1im"
                  placeholder="enter destination here"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Start Date
                </label>
              </div>
              <div className="input1m">
                <DatePicker
                  selected={clientDetails.startdate}
                  id="startdate"
                  className="fname"
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      startdate: e,
                    }))
                  }
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  No. of days
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.days}
                  type="number"
                  id="days"
                  className="input1im"
                  placeholder="enter days here"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Number of Adults
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.adults}
                  type="text"
                  id="adults"
                  className="input1im"
                  placeholder="adults count"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Number of Children
                </label>
              </div>
              <div className="input1m">
                <input
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.children}
                  type="text"
                  id="children"
                  className="input1im"
                  placeholder="children count"
                />
              </div>
            </div>
            <div className="uNamem">
              <div className="unameinnerm passm">
                <label htmlFor="email" className="label1m">
                  Comments (optional)
                </label>
              </div>
              <div className="input1m">
                <textarea
                  onChange={(e) =>
                    setClientDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                  value={clientDetails.comments}
                  type="text"
                  id="comments"
                  className="input1im taream"
                  placeholder="enter your comments here"
                />
              </div>
            </div>
            <div className="signBtnm">
              <button className="btnm" onClick={handleNum}>
                Add Client
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Client;
