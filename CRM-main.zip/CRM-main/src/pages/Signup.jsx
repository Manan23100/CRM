import React, { useState } from "react";
import "./Signup.css";
import axios from "axios";
import validator from 'validator'
import { Link, useNavigate } from "react-router-dom";
import { BiBookBookmark } from "react-icons/bi";
import Navbar from "../components/navbar/Navbar";

const Signuppage = () => {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [error, setError] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null)
 const [nameError, setNameError] = useState(null);
  function isValidEmail(email) {
    return /\S+@\S+\.\S+/.test(email);
  }

 
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleNum = async (e) => {
    e.preventDefault();

    if (!isValidEmail(email)) {
      setError('Email is invalid');
    }
    else {
      setError(null);
    }
    if (!validator.isStrongPassword(password, {
      minLength: 8, minLowercase: 1,
      minUppercase: 1, minNumbers: 1
    })) {
 
      setErrorMessage('Is Not Strong Password')
     
    } else {
      setErrorMessage(null)
    }
    if (!username) {
      setNameError('Please Enter Name')
    }
    else{
      setNameError(null);
    }
     if(error==null && errorMessage==null && nameError==null) {
     
      try {
        const res = await axios.post(
          "http://localhost:2100/api/auth/register",
          {
            username,
            email,
            password,
          }
        );

    

        return nav("/login");
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    <>
      {/* <div className="navbars1">
        <div>
          <BiBookBookmark className="firstLogo" />
        </div>
        <div className="navContainers">
          <div>
            <Link to="/" style={{ color: "inherit", textDecoration: "none" }}>
              <span className="logos">Holidays Crowd</span>
            </Link>
          </div>
          <div className="navItems">
            <Link to="/home" className="navButtons">
              Home
            </Link>
            <Link to="/login" className="navButtons">
              LogIn
            </Link>
            <Link to="/signup" className="navButtons">
              SignUp
            </Link>
          </div>
        </div>
      </div> */}
      <Navbar />
      <div className="topOne">
        <div className="logo">
          <img
            src="http://holidaycrowd.in/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Flogo.8cbb6f15.png&w=1920&q=75"
            alt="logo"
            className="imgOne"
          />
        </div>
        <div className="hcg">
          <h1 className="heading">Holidays Crowd</h1>
        </div>
      </div>
      <div className="toppers">
        <div className="logintothere">
          <div className="logged">
            <h1 className="loginheres">SignUp to Holidays Crowd</h1>
          </div>
        </div>
        <form className="formofSignup">
          <div className="uNamethere">
            <div className="unameinnerd">
              <label htmlFor="username" className="label1">
                Username
              </label>
            </div>
            <div className="input1">
              <input
                onChange={(e) => {
                  setUsername(e.target.value);
                }}
                value={username}
                type="text"
                className="input1i1"
                placeholder="enter name here"
              />

              <div>
                {error && <h5 style={{ color: "red" }}>{nameError}</h5>}
              </div>
            </div>
          </div>
          <div className="uNamethere">
            <div className="unameinnerd emailit">
              <label htmlFor="email" className="label1">
                Email
              </label>
            </div>
            <div className="input1">
              <input
                required="true"
                requiredTxt="Email is required"
                value={email}
                type="email"
                className="input1i1"
                placeholder="username@domain.com"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
              />
              <div>{error && <h5 style={{ color: "red" }}>{error}</h5>}</div>
            </div>
          </div>

          <div className="uNamethere">
            <div className="unameinnerd passit">
              <label htmlFor="email" className="label1">
                Password
              </label>
            </div>
            <div className="input1">
              <input
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                value={password}
                type="password"
                className="input1i1"
                placeholder="enter password here"
              />

              <div>
                {errorMessage && (
                  <h5 style={{ color: "red" }}>{errorMessage}</h5>
                )}
              </div>
            </div>
          </div>
          <Link to="/Login" className="frLink1">
            Already Login (Click here!)
          </Link>
          <div className="signBtnhere">
            <button className="btn21" onClick={handleNum}>
              SignUp
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default Signuppage;
