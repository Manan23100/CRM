import { createContext, useEffect, useState } from "react";

export const UserContext = createContext();

const Usercheck = ({ children }) => {
  const [email, setEmail] = useState("");
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    var hours = 24; // Reset when storage is more than 24hours
    var now = new Date().getTime();
    sessionStorage.setItem("datakey", JSON.stringify(email));
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, hours * 60 * 60 * 1000);
  }, [email]);

  return (
    <UserContext.Provider
      value={{
        email,
        setEmail,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export default Usercheck;
