import React from "react";
import { useState } from "react";
import "./Itinerarycompo.css";

const Itinerarycompo = () => {
  const [schedule, setSchedule] = useState({
    title: "",
    description: "",
  });

  console.log(schedule);

  return (
    <>
      <div className="itineraryArea">
        <div className="daywise">
          <div>
            <p className="paraday">Day:1 Title</p>
            <input
              value={schedule.title}
              type="text"
              className="titledd"
              id="title"
              placeholder="title here"
              onChange={(e) =>
                setSchedule((prev) => ({
                  ...prev,
                  [e.target.id]: e.target.value,
                }))
              }
            />
          </div>
          <div>
            <p className="desc">Description</p>
            <textarea
              value={schedule.description}
              type="text"
              id="description"
              className="descID"
              placeholder="description here"
              onChange={(e) =>
                setSchedule((prev) => ({
                  ...prev,
                  [e.target.id]: e.target.value,
                }))
              }
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default Itinerarycompo;
