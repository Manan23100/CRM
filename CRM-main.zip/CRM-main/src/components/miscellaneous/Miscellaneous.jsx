import React from "react";
import { useState } from "react";
import { AiFillWarning } from "react-icons/ai";
import "./Miscellaneous.css";

const Miscellaneous = () => {
  const [terms, setTerms] = useState("");
  return (
    <>
    <div className="miscellaneous">
      <div className="itinerary">
        <div>
          <AiFillWarning />
          <span className="ggg">Miscellaneous</span>
        </div>
        <hr className="hrr" />
      </div>
      <div className="miscc">
        <div className="tc">
          <span className="tcs">Terms & Condition</span>
          <span className="pp">
            <input type="checkbox" id="perperson" name="perperson" />
            <label htmlFor="vehicle1" className="udtc">
              Use Default T&C
            </label>
          </span>
          <form className="tamiss">
            <textarea
              name=""
              id="ta1"
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
            >
          
            </textarea>
          </form>
        </div>
        {/* <div className="otI">
          <div className="oip">
            <span className="ois">Other Information</span>
          </div>
          <div className="oi1">
            <textarea name="" id="oita"></textarea>
          </div>
        </div> */}
      </div>
    </div>
    </>
  );
};

export default Miscellaneous;
