import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";
import { BiBookBookmark } from "react-icons/bi";
import Navbar from "../navbar/Navbar";
const Home = () => {
  return (
    <>
      {/* <div className="navbars1">
        <BiBookBookmark className="firstLogoo" />
        <div className="navContainered">
          <Link to="/" style={{ color: "inherit", textDecoration: "none" }}>
            <span className="logosss">Holidays Crowd</span>
          </Link>
          <div className="navItemsss">
            <Link to="/home" className="navButtoned">
              Home
            </Link>
            <Link to="/login" className="navButtoned">
              LogIn
            </Link>
            <Link to="/signup" className="navButtoned">
              SignUp
            </Link>
          </div>
        </div>
      </div> */}
      <Navbar/>

      <div className="imgmain">
        {/* <img
        {/* <img
          className="img1"
         src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
          alt=""
        /> */}
      </div>
      <div className="bg-text">
        {/* <p className="wel">WELCOME</p> */}
        {/* <h1 className="hdr">We Are Here To Help You Out!</h1> */}
        <p className="wel">
          Management and Growth for Travel Agency, Tour Operators and DMCs
        </p>
        <p className="aim">
          “The aim of marketing is to help you out with your itenray problem"
        </p>
        <p className="longP2">
          A software suite for Travel Agencies and Tour Operators to grow sales,
          ease hotel reservation and cab bookings, and to increase healthy cash
          flow.
        </p>
        <button class="custom-btn btn-16">
          {" "}
          <Link to="/signup" className="btn-text">
            SignUp →
          </Link>
        </button>
      </div>
    </>
  );
};

export default Home;
