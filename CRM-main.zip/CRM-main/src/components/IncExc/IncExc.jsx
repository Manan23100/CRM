import React from "react";
import Itinerary from "../itinerary/Itinerary";
import "./IncExc.css";
import { FaPuzzlePiece } from "react-icons/fa";
import { MdOutlineFlight } from "react-icons/md";
import { BiTrain } from "react-icons/bi";
import { TbBus } from "react-icons/tb";
import { useState } from "react";

const IncExc = ({ days, setInclude, include }) => {
  const [showComment, setShowComment] = useState(false);
  const handleComment = (e) => {
    e.preventDefault();
    setShowComment(true);
  };
  const handleComments = (e) => {
    e.preventDefault();
    setShowComment(false);
  };

  const [showComment2, setShowComment2] = useState(false);
  const handleComment2 = (e) => {
    e.preventDefault();
    setShowComment2(true);
  };
  const handleComment2a = (e) => {
    e.preventDefault();
    setShowComment2(false);
  };

  const [showComment3, setShowComment3] = useState(false);
  const handleComment3 = (e) => {
    e.preventDefault();
    setShowComment3(true);
  };
  const handleComment3a = (e) => {
    e.preventDefault();
    setShowComment3(false);
  };

  const [showComment4, setShowComment4] = useState(false);
  const handleComment4 = (e) => {
    e.preventDefault();
    setShowComment4(true);
  };
  const handleComment4a = (e) => {
    e.preventDefault();
    setShowComment4(false);
  };

  const [showF, setShowF] = useState(false);
  const handleF = (e) => {
    e.preventDefault();
    setShowF(true);
  };

  const [showT, setShowT] = useState(false);
  const handleT = (e) => {
    e.preventDefault();
    setShowT(true);
  };

  const [showB, setShowB] = useState(false);
  const handleB = (e) => {
    e.preventDefault();
    setShowB(true);
  };

  return (
    <>
      <div className="incexc">
        <div className="incexcmain">
          <FaPuzzlePiece />
          <div className="writeincexc">
            <span>Inclusions/Exclusions</span>
          </div>
        </div>
        <hr />
      </div>
      <div className="openIncExc">
        <form className="formofincexc">
          <div className="leftincexc">
            <div className="mie">
              <div className="meanPlan">
                <p>MEAL PLAN</p>
              </div>
              <div className="rightinc">
                <span>Include</span>
              </div>
              <div className="rightexc">
                <span>Exclude</span>
              </div>
            </div>
            <hr />
            <div className="leftthings">
              <div className="lbf">
                <p>Breakfast</p>
              </div>
              <div className="rightradio">
                 {" "}
                <input
                  type="radio"
                  id="breakfast"
                  className="radio1"
                  name="ff"
                  value={include.breakfast}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: (e.target.value = true),
                    }))
                  }
                />
                 {" "}
                <input
                  type="radio"
                  id="radio2"
                  className="radio2"
                  name="ff"
                  value=""
                  defaultChecked
                />
              </div>
            </div>
            <div className="leftthings">
              <div className="lbf">
                <p>Lunch</p>
              </div>
              <div className="rightradio">
                 {" "}
                <input
                  type="radio"
                  id="lunch"
                  className="radio3"
                  name="a"
                  value={include.lunch}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: (e.target.value = true),
                    }))
                  }
                />
                 {" "}
                <input
                  type="radio"
                  id="radio4"
                  className="radio4"
                  name="a"
                  value=""
                  defaultChecked
                />
              </div>
            </div>
            <div className="leftthings">
              <div className="lbf">
                <p>Dinner</p>
              </div>
              <div className="rightradio">
                 {" "}
                <input
                  type="radio"
                  id="dinner"
                  className="radio5"
                  name="b"
                  value={include.dinner}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: (e.target.value = true),
                    }))
                  }
                />
                 {" "}
                <input
                  type="radio"
                  id="radio6"
                  className="radio6"
                  name="b"
                  value=""
                  defaultChecked
                />
              </div>
            </div>
            {showComment && (
              <div className="leftthings">
                <div className="lbf">
                  <p>Comments</p>
                  <textarea
                    name=""
                    id="showComment"
                    className="tarea"
                    cols="30"
                    rows="10"
                    value={include.showComment}
                    onChange={(e) =>
                      setInclude((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                  ></textarea>
                </div>
              </div>
            )}
          </div>
          {/* </div> */}
          {/* ))} */}
          <span className="btnInc">
            <button className="mainBtnINc" onClick={handleComment}>
              Add Comments
            </button>
          </span>
          <span className="btnInc">
            <button className="mainBtnINc rbtn" onClick={handleComments}>
              Remove Comments
            </button>
          </span>
          {/* transportation details */}
          <div className="vehicle">
            <p>Transport Details</p>
          </div>
          <hr />
          <div className="leftthings">
            <div className="lbf">
              <p>
                <MdOutlineFlight /> Flight
              </p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="flight"
                className="radio70"
                name="ab"
                value={include.flight}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio71"
                className="radio71"
                name="ab"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showF && (
            <div className="leftthings">
              <div className="lbf">
                <textarea
                  name=""
                  id="showF"
                  className="tup"
                  cols="30"
                  rows="10"
                  value={include.showF}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
                <form>
                  <label for="files">Select files:</label>
                  <input type="file" id="files" name="files" multiple />
                </form>
              </div>
            </div>
          )}
          <span className="btnF">
            <button className="mainBtnF" onClick={handleF}>
              Add Details
            </button>
          </span>
          <div className="leftthings">
            <div className="lbf">
              <p>
                <BiTrain /> Train
              </p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="train"
                className="radio72"
                name="dq"
                value={include.train}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio73"
                className="radio73"
                name="dq"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showT && (
            <div className="leftthings">
              <div className="lbf">
                <textarea
                  name=""
                  id="showT"
                  className="tup"
                  cols="30"
                  rows="10"
                  value={include.showT}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
                <form>
                  <label for="files">Select files:</label>
                  <input type="file" id="files" name="files" multiple />
                </form>
              </div>
            </div>
          )}
          <span className="btnF">
            <button className="mainBtnF" onClick={handleT}>
              Add Details
            </button>
          </span>
          <div className="leftthings">
            <div className="lbf">
              <p>
                <TbBus /> Bus
              </p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="bus"
                className="radio74"
                name="ea"
                value={include.bus}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio75"
                className="radio75"
                name="ea"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showB && (
            <div className="leftthings">
              <div className="lbf">
                <textarea
                  name=""
                  id="showB"
                  className="tup"
                  cols="30"
                  rows="10"
                  value={include.showB}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
                <form>
                  <label for="files">Select files:</label>
                  <input type="file" id="files" name="files" multiple />
                </form>
              </div>
            </div>
          )}
          <span className="btnF">
            <button className="mainBtnF" onClick={handleB}>
              Add Details
            </button>
          </span>
          {/* vehicles here */}
          <div className="vehicle">
            <p>VEHICLE</p>
          </div>
          <hr />
          <div className="leftthings">
            <div className="lbf">
              <p>SUV Cab</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="suvCab"
                className="radio7"
                name="c"
                value={include.suvCab}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio8"
                className="radio8"
                name="c"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>Small Cab</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="smallCab"
                className="radio9"
                name="d"
                value={include.smallCab}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio10"
                className="radio10"
                name="d"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>Sedan Cab</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="sedanCab"
                className="radio11"
                name="e"
                value={include.sedanCab}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio12"
                className="radio12"
                name="e"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>AC Cab</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="acCab"
                className="radio41"
                name="zz"
                value={include.acCab}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio42"
                className="radio42"
                name="zz"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>NON-AC Cab</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="nonAcCab"
                className="radio43"
                name="er"
                value={include.nonAcCab}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio44"
                className="radio44"
                name="er"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showComment2 && (
            <div className="leftthings">
              <div className="lbf">
                <p>Comments</p>
                <textarea
                  name=""
                  id="showComment2"
                  className="tarea"
                  cols="30"
                  rows="10"
                  value={include.showComment2}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
              </div>
            </div>
          )}
          <span className="btnInc">
            <button className="mainBtnINc" onClick={handleComment2}>
              Add Comments
            </button>
          </span>
          <span className="btnInc">
            <button className="mainBtnINc rbtn" onClick={handleComment2a}>
              Remove Comments
            </button>
          </span>
          <div className="vehicle">
            <p>Activities</p>
          </div>
          <hr />
          <div className="leftthings">
            <div className="lbf">
              <p>Evening Cruise</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="eveningCruise"
                className="radio35"
                name="q"
                value={include.eveningCruise}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio36"
                className="radio36"
                name="q"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>Jeep Safari</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="jeepSafari"
                className="radio37"
                name="s"
                value={include.jeepSafari}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio38"
                className="radio38"
                name="s"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>Elephant Safari</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="elephantSafari"
                className="radio39"
                name="t"
                value={include.elephantSafari}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio40"
                className="radio40"
                name="t"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showComment3 && (
            <div className="leftthings">
              <div className="lbf">
                <p>Comments</p>
                <textarea
                  name=""
                  id="showComment3"
                  className="tarea"
                  cols="30"
                  rows="10"
                  value={include.showComment3}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
              </div>
            </div>
          )}
          <span className="btnInc">
            <button className="mainBtnINc" onClick={handleComment3}>
              Add Comments
            </button>
          </span>
          <span className="btnInc">
            <button className="mainBtnINc rbtn" onClick={handleComment3a}>
              Remove Comments
            </button>
          </span>
          {/* transportation here */}
          <div className="transportation">
            <p>Accomodation</p>
          </div>
          <hr />
          <div className="leftthings">
            <div className="lbf">
              <p>Homestay</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="homeStay"
                className="radio15"
                name="g"
                value={include.homeStay}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio16"
                className="radio16"
                name="g"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>Budget Hotels</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="budgetHotel"
                className="radio17"
                name="h"
                value={include.budgetHotel}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio18"
                className="radio18"
                name="h"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>3 Star Hotels</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="threeStarHotel"
                className="radio19"
                name="i"
                value={include.threeStarHotel}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio20"
                className="radio20"
                name="i"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>4 Star Hotels</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="fourStarHotel"
                className="radio21"
                name="j"
                value={include.fourStarHotel}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio22"
                className="radio22"
                name="j"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>5 Star Hotels</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="fiveStarHotel"
                className="radio23"
                name="k"
                value={include.fiveStarHotel}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio24"
                className="radio24"
                name="k"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>Sharing Houseboat</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="sharingHouseboat"
                className="radio25"
                name="l"
                value={include.sharingHouseboat}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio26"
                className="radio26"
                name="l"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>Pvt Houseboat</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="pvtHouseboat"
                className="radio27"
                name="m"
                value={include.pvtHouseboat}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio28"
                className="radio28"
                name="m"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>Budget Houseboat</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="budgetHouseboat"
                className="radio29"
                name="n"
                value={include.budgetHouseboat}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio30"
                className="radio30"
                name="n"
                value=""
                defaultChecked
              />
            </div>
          </div>{" "}
          <div className="leftthings">
            <div className="lbf">
              <p>Premium Houseboat</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="premiumHouseboat"
                className="radio31"
                name="o"
                value={include.premiumHouseboat}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio32"
                className="radio32"
                name="o"
                value=""
                defaultChecked
              />
            </div>
          </div>
          <div className="leftthings">
            <div className="lbf">
              <p>Luxury Houseboat</p>
            </div>
            <div className="rightradio">
               {" "}
              <input
                type="radio"
                id="luxuryHouseboat"
                className="radio33"
                name="p"
                value={include.luxuryHouseboat}
                onChange={(e) =>
                  setInclude((prev) => ({
                    ...prev,
                    [e.target.id]: (e.target.value = true),
                  }))
                }
              />
               {" "}
              <input
                type="radio"
                id="radio34"
                className="radio34"
                name="p"
                value=""
                defaultChecked
              />
            </div>
          </div>
          {showComment4 && (
            <div className="leftthings">
              <div className="lbf">
                <p>Comments</p>
                <textarea
                  name=""
                  id="showComment4"
                  className="tarea"
                  cols="30"
                  rows="10"
                  value={include.showComment4}
                  onChange={(e) =>
                    setInclude((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                ></textarea>
              </div>
            </div>
          )}
          <span className="btnInc">
            <button className="mainBtnINc" onClick={handleComment4}>
              Add Comments
            </button>
          </span>
          <span className="btnInc">
            <button className="mainBtnINc rbtn" onClick={handleComment4a}>
              Remove Comments
            </button>
          </span>
        </form>
      </div>
      {/* <Itinerary days={days} /> */}
    </>
  );
};

export default IncExc;
