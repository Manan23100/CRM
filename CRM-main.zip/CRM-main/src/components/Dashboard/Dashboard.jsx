import React, { useEffect, useState } from "react";
import "./Dashboard.css";
import { Link, useNavigate, Navigate } from "react-router-dom";
import axios from "axios";
import Cookies from "universal-cookie";
import List from "../../pages/List";
import { RiDeleteBinLine } from "react-icons/ri";
import Sidebar from "../sideComponent/Sidebar";
import Client from "../../pages/Client";
// add hovered class to selected list item
let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
  });
  this.classList.add("hovered");
}

list.forEach((item) => item.addEventListener("mouseover", activeLink));

// // Menu Toggle
// let toggle = document.querySelector(".toggle");
// let navigation = document.querySelector(".navigation");
// let main = document.querySelector(".main");

// toggle.onclick = function () {
//   navigation.classList.toggle("active");
//   main.classList.toggle("active");
// };

const Dashboard = () => {
  const [open, setOpen] = useState(false);
  const toggle = () => {
    setOpen(!open);
  };

  const [pop, setPop] = useState(false);
  const openpop = () => {
    setPop(!pop);
  };
  const cokies = new Cookies();

  const [timer, setTimer] = useState(86400);
  const navigate = useNavigate();
  useEffect(() => {
    if (timer > 0) {
      const myTimeout = setTimeout(Timer, 1000);
    } else {
      navigate("/");
    }
  }, [timer]);
  function Timer() {
    setTimer(timer - 1);
  }

  const [inputText, setInputText] = useState("");

  let inputHandler = (e) => {
    //convert input text to lower case
    var lowerCase = e.target.value.toLowerCase();
    setInputText(lowerCase);
  };

  const cookies = new Cookies();
  const Token = cookies.get("Token");
  const nav = useNavigate();
  const [data, setData] = useState([]);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  // const [cnumber, setCnumber] = useState();
  // const [destination, setDestination] = useState("");

  useEffect(() => {
    const restemail = async () => {
      try {
        const res = await axios.post(
          "http://localhost:2100/api/auth/tokenverify",
          { Token }
        );

        setName(res.data.usercheck.username);
        // setCnumber(res.data.usercheck.contactNumber);
        // setDestination(res.data.usercheck.destination)
        return setEmail(res.data.usercheck.email);
      } catch (error) {
        console.log(error);
      }
    };

    restemail();
    rest();
  }, [Token, email]);

  const [totalsale, setTotalsale] = useState(0);
  const [tagsarray, setTagsarray] = useState([]);
  // console.log(tagsarray, "tagsarray")
  // const[response, updateResponse] = useState([]);

  // console.log(response ,"response");

  const rest = async () => {
    try {
      const res = await axios.post("http://localhost:2100/api/auth/allclient", {
        email,
      });

      return setData(res.data.data);
    } catch (error) {
      console.log(error);
    }
  };

  // const [delivered, setDelivered] = useState("");
  // const [delivered2, setDelivered2] = useState("");
  const [checkbutton, setCheckbutton] = useState(false);
  const [checkbutton2, setCheckbutton2] = useState(false);
  const [checkbutton3, setCheckbutton3] = useState(false);
  const [checkbutton4, setCheckbutton4] = useState(false);
  const [checkbutton5, setCheckbutton5] = useState(false);
  const [checkbutton6, setCheckbutton6] = useState(false);

  // useEffect( ()=>{

  //   console.log(checkbutton);
  //  if(checkbutton){
  //   const getalldatanewlead = [];
  //   for(var i =0;i<data.length;i++){
  //     console.log(data[i].Status,"data.satatus")
  //      if(data[i].Status == "New Lead"){
  //       getalldatanewlead.push(data[i]);

  //      }
  //   }

  //   if(response.length==1 && response[0].length==0){
  //     updateResponse(getalldatanewlead);
  //   }
  //   else{
  //      updateResponse([...response, getalldatanewlead]);
  //   }

  //  }
  //  else if(!checkbutton){

  //   for(var i =0;i<response.length;i++){
  //     console.log(response[i].length, "length")
  //     if(response[i] ){
  //       for(var j=0;j<response[i].length;j++){
  //         console.log(j,"j")
  //         if(response[i][j].Status ==='New Lead'){
  //           response.splice(i,1);
  //           return
  //         }
  //         console.log(response[i], "length")
  //       }
  //     }
  //     else{
  //       return ;
  //     }

  //   }
  //  }

  // },[checkbutton])
  // useEffect( ()=>{

  // if(checkbutton2){
  //   const getalldataconverted = [];
  //   for(var i =0;i<data.length;i++){
  //     console.log(data[i].Status,"data.satatus")
  //      if(data[i].Status == "Converted"){
  //       getalldataconverted.push(data[i]);
  //      }
  //   }

  //   if(response.length==1 && response[0].length==0){
  //     updateResponse(getalldataconverted);
  //   }else{
  //     updateResponse([...response, getalldataconverted]);
  //   }
  // }

  // else if(!checkbutton2){
  //   for(var i =0;i<response.length;i++){
  //     console.log(response[i].length, "length")
  //     if(response[i] ){
  //       for(var j=0;j<response[i].length;j++){
  //         console.log(j,"j")
  //         if(response[i][j].Status ==='Converted'){
  //           response.splice(i,1);
  //           return
  //         }
  //         console.log(response[i], "length")
  //       }
  //     }
  //     else{
  //       return ;
  //     }

  //   }
  //  }
  // },[checkbutton2])

  // useEffect(() => {
  //   try {
  //     if (checkbutton) {
  //       return setDelivered("New Lead");
  //     } else {

  //       updateCheckdata((checkdata) =>
  //       checkdata.filter((_, user) => user.user.Status !== delivered)
  //     );

  //       return setDelivered("");

  //     }
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }, [checkbutton]);

  // useEffect(() => {
  //   try {
  //     if (checkbutton2) {
  //       return setDelivered2("Converted");
  //     } else {

  //         updateCheckdata((checkdata) =>
  //         checkdata.filter((user) => user.user.Status !== delivered2)
  //       );

  //       return setDelivered2("");
  //       //    setCheckdata(...checkdata, );
  //     }
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }, [checkbutton2]);

  // useEffect(() => {
  //   const restagain = async () => {
  //     try {
  //       if (delivered2 !== "") {
  //         const res = await axios.post(
  //           "http://localhost:2100/api/auth/filter",
  //           {
  //             delivered: delivered2,
  //           }
  //         );
  //      console.log(res, "res");

  //      if(checkdata[0].user === undefined){
  //       return  updateCheckdata([res.data]);
  //      }

  //       console.log("out converted")
  //       return updateCheckdata([...checkdata, res.data]);

  //       }
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };
  //   restagain();
  // }, [delivered2]);

  // useEffect(() => {
  //   const resti = async () => {
  //     try {
  //       const res = await axios.post("http://localhost:2100/api/auth/filter", {
  //         delivered,
  //       });

  //       console.log(res,"res");
  //       if(checkdata[0].user === undefined){
  //         return  updateCheckdata([res.data]);

  // }

  // console.log("okay dekho")
  // return updateCheckdata([...checkdata, res.data]);

  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };
  //   resti();
  // }, [delivered]);

  // const [checkdata, updateCheckdata] = useState([]);

  // console.log(checkdata, "chking data")
  // const handleNum = async (e) => {
  //   e.preventDefault();
  // };
  const [totalontrip, settotalontrip] = useState(0);
  const [finaldata, setFinaldata] = useState([]);
  console.log(finaldata, "finaldata");
  useEffect(() => {
    setFinaldata(data);

    let totalsalecount = 0;
    var totalontrip = 0;
    for (var i = 0; i < data.length; i++) {
      if (
        data[i].Status === "Converted" ||
        data[i].Status === "Past-Trip" ||
        data[i].Status === "On-Trip"
      ) {
        totalsalecount++;
      }
      if (data[i].Status === "On-Trip") {
        totalontrip++;
      }
    }
    console.log(totalsalecount, "total");
    settotalontrip(totalontrip);
    return setTotalsale(totalsalecount);
  }, [data]);

  useEffect(() => {
    if (checkbutton) {
      setTagsarray((prev) => [...prev, "New Lead"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "New Lead"));
    }
  }, [checkbutton]);

  useEffect(() => {
    if (checkbutton2) {
      setTagsarray((prev) => [...prev, "Converted"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "Converted"));
    }
  }, [checkbutton2]);
  useEffect(() => {
    if (checkbutton3) {
      setTagsarray((prev) => [...prev, "Past-Trip"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "Past-Trip"));
    }
  }, [checkbutton3]);

  useEffect(() => {
    if (checkbutton4) {
      setTagsarray((prev) => [...prev, "InProgress"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "InProgress"));
    }
  }, [checkbutton4]);

  useEffect(() => {
    if (checkbutton5) {
      setTagsarray((prev) => [...prev, "On-Trip"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "On-Trip"));
    }
  }, [checkbutton5]);

  useEffect(() => {
    if (checkbutton6) {
      setTagsarray((prev) => [...prev, "Cancelled"]);
    } else {
      setTagsarray((prev) => prev.filter((fruit) => fruit !== "Cancelled"));
    }
  }, [checkbutton6]);

  useEffect(() => {
    const aar = [];
    for (var k = 0; k < tagsarray.length; k++) {
      console.log(tagsarray[k], "tagsaaray");

      for (var i = 0; i < data.length; i++) {
        if (data[i].Status === tagsarray[k]) {
          aar.push(data[i]);
        }
      }

      setFinaldata(aar);
    }
  }, [tagsarray]);

  useEffect(() => {
    if (
      !checkbutton &&
      !checkbutton2 &&
      !checkbutton3 &&
      !checkbutton4 &&
      !checkbutton5 &&
      !checkbutton6
    ) {
      setFinaldata(data);
    }
  }, [
    checkbutton,
    checkbutton2,
    checkbutton3,
    checkbutton4,
    checkbutton5,
    checkbutton6,
  ]);
  // useEffect(()=>{

  //   if(( response.length >=0 &&( checkbutton || checkbutton2 ))){

  //     var allfinaldata = [];
  //     if(response.length==0){
  //       for(var j=0;j<response[0].length;j++){
  //         allfinaldata.push(response[0][j]);
  //        }
  //     }
  //     for(var i =0;i<response.length;i++){

  //      console.log(response[i],"response[i");
  //      for(var j=0;j<response[i].length;j++){
  //       allfinaldata.push(response[i][j]);
  //      }

  //     }
  //      console.log(allfinaldata,"allfinaldata");
  //      setFinaldata(allfinaldata);
  //    }

  //    else{
  //     setFinaldata(data);
  //    }

  // },[response,data])

  //   useEffect(()=>{
  //     if(!checkbutton && finaldata.length>0){
  //      for(var i =0;i<finaldata.length;i++){

  //        if(finaldata[i].Status === 'New Lead'){
  //          finaldata.splice(i,3)
  //          console.log(finaldata,"in update loop")
  //        }
  //      }
  //    }

  //    else if(!checkbutton2 && finaldata.length>0){
  //     for(var j=0;j<finaldata.length;j++){

  //       if(finaldata[j].Status === 'Converted'){
  //         finaldata.splice(j,2)
  //         console.log(finaldata,"in update loop")
  //        }
  //     }
  //    }

  //  },[checkbutton, checkbutton2])

  const [deletepop, setDeletedpop] = useState(false);
  const [deltrip, setDeltrip] = useState();
  const [usetrip, setUsetrip] = useState();

  const [usetrippop, setUsetrippop] = useState(false);
  const deletetrip = async (id) => {
    try {
      console.log(id, "checking");
      const res = await axios.post(
        "http://localhost:2100/api/client/deletebyid",
        {
          id,
        }
      );

      return window.location.reload(true);
    } catch (error) {
      console.log(error, "error");
    }
  };

  useEffect(() => {
    if (usetrippop) {
      const getdata = async () => {
        try {
          const res1 = await axios.post(
            "http://localhost:2100/api/client/getuserdetail",
            {
              id: usetrip,
            }
          );
          console.log(res1, "res");

          return nav(`/BasicDetail/${res1.data.userdetail._id}`, {
            state: { res: res1.data.userdetail._id, des:"dashboard" },
          });
        } catch (error) {
          console.log(error, "error");
        }
      };

      getdata();
    }
  }, [usetrip]);

  return !Token ? (
    <Navigate to="/login" />
  ) : (
    <>
      <div className="container">
        {/* navbar */}
        <Sidebar />
        {/* <!-- ========================= Main ==================== --> */}
        <div className="main">
          <div className="topbar">
            <div className="toggle">
              <ion-icon name="menu-outline"></ion-icon>
            </div>

            <div style={{ position: "relative" }} class="search">
              <label>
                <input
                  onChange={inputHandler}
                  type="text"
                  placeholder="Search here"
                />
                <ion-icon name="search-outline"></ion-icon>
              </label>
            </div>

            <div class="cs-ref">
              <Link
                class="cs-dribbble"
                to="https://dribbble.com/shots/10498537-UI-Search-bar-with-suggestions"
                target="_blank"
              >
                <div id="svgDribbble"></div>
              </Link>
              <Link
                class="cs-twitter"
                target="_blank"
                to="https://twitter.com/CosWiSe"
              >
                <div id="svgTwitter"></div>
              </Link>
            </div>
            <div class="user">
              <h3>Hello {name.toUpperCase()}!</h3>
            </div>
          </div>

          {/* <!-- ======================= Cards ================== --> */}
          <div className="cardBox">
            <div className="card">
              <div className="cardSize1">
                <div className="numbers">{data.length}</div>
                <div className="cardName">Total Trip</div>
              </div>

              <div className="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
              </div>
            </div>

            <div className="card">
              <div className="cardSize2">
                <div className="numbers">{totalsale}</div>
                <div className="cardName">Sales</div>
              </div>

              <div className="iconBx">
                <ion-icon name="cart-outline"></ion-icon>
              </div>
            </div>

            <div className="card">
              <div className="cardSize3">
                <div className="numbers">{totalontrip}</div>
                <div className="cardName">On Trip</div>
              </div>

              <div className="iconBx">
                <ion-icon name="chatbubbles-outline"></ion-icon>
              </div>
            </div>

            <div className="card">
              <div className="cardSize4">
                <div className="numbers">₹0</div>
                <div className="cardName">Earning</div>
              </div>

              <div className="iconBx">
                <ion-icon name="cash-outline"></ion-icon>
              </div>
            </div>
          </div>

          {/* <!-- ================ Order Details List ================= --> */}
          <div className="details">
            <div className="recentOrders">
              <div className="cardHeader">
                <h2>All Trips</h2>

                <div onClick={openpop} className="btn1">
                  Add Client
                </div>
                {deletepop && (
                  <div className="cpop">
                    <div className="cpop1">
                      <div className="del">
                        <p className="deleteit">
                          Do you really want to delete it?
                        </p>
                      </div>
                      <div className="dell">
                        <div className="btnnn">
                          <div onClick={() => deletetrip(deltrip)}>Confirm</div>
                        </div>
                        <div className="btnnnn">
                          <div onClick={() => setDeletedpop(false)}>Cancel</div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="btn">
                  <div id="dropdown-content">
                    <div onClick={toggle}>
                      <span id="show-dropdown" className="btn">
                        Status
                      </span>
                    </div>
                    {open && (
                      <div>
                        <div>
                          <input
                            id="check-1"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton(!checkbutton);
                            }}
                          />
                          <label>New Lead</label>
                        </div>
                        <div>
                          <input
                            id="check-2"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton2(!checkbutton2);
                            }}
                          />
                          <label>Converted</label>
                        </div>
                        <div>
                          <input
                            id="check-3"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton3(!checkbutton3);
                            }}
                          />
                          <label>Past-Trip</label>
                        </div>
                        <div>
                          <input
                            id="check-3"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton4(!checkbutton4);
                            }}
                          />
                          <label>InProgress</label>
                        </div>
                        <div>
                          <input
                            id="check-4"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton5(!checkbutton5);
                            }}
                          />
                          <label>On-Trip</label>
                        </div>
                        <div>
                          <input
                            id="check-5"
                            name="checked-1"
                            type="checkbox"
                            onChange={(e) => {
                              setCheckbutton6(!checkbutton6);
                            }}
                          />
                          <label>Cancelled</label>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                {/* <Link to="#" className="btn">
                  View All
                </Link> */}
              </div>

              <table>
                <thead>
                  <tr>
                    <td>Trip ID</td>
                    <td>Name</td>
                    {/* <td>Email</td> */}
                    <td>Contact Number</td>
                    <td>Destination</td>
                    <td>Start Date</td>
                    <td>Days</td>
                    <td>No. of Pax</td>
                    <td>Trip Status</td>
                    <td>Cost</td>
                    <td></td>
                  </tr>
                </thead>

                <tbody>
                  {inputText ? (
                    <List input={inputText} />
                  ) : (
                    finaldata.map((item, index) => (
                      <tr key={index}>
                        <td
                          onClick={() => (
                            setUsetrippop(!usetrippop), setUsetrip(item._id)
                          )}
                          // onClick={wentto , setUsetrip(item._id)}
                          style={{ cursor: "pointer" }}
                        >
                          {item.tripId}
                        </td>
                        <td>{item.clientname}</td>

                        <td>{item.contactNumber}</td>

                        <td>{item.destination}</td>

                        <td>{item.startdate}</td>

                        <td>{item.days}</td>

                        <td>
                          <td>
                            {item.adults + "A • "}
                            {item.children + "C"}
                          </td>
                        </td>

                        <td>{item.Status}</td>
                        <td>0</td>
                        <td
                          style={{ cursor: "pointer" }}
                          onClick={() => (
                            setDeletedpop(!deletepop), setDeltrip(item._id)
                          )}

                          // onClick={() => deletetrip(item._id)}
                        >
                          <RiDeleteBinLine />
                        </td>
                        {/* <td>
                          <span class="status delivered"> Sikkim-Dargling</span>
                        </td> */}
                      </tr>
                    ))
                  )}
                </tbody>
                {/* <tbody>
                  {" "}
                  <tr>
                    <td>checking</td>
                    <td>again</td>
                    <td>Paid</td>
                    <td>
                      <span className="status delivered">not-Delivered</span>
                    </td>
                  </tr>
                </tbody> */}
              </table>
            </div>

            {/* <!-- ================= New Customers ================ --> */}
            {/* <div className="recentCustomers">
              <div className="cardHeader">
                <h2>Recent Customers</h2>
              </div>

              <table>
                {data.map((item, index) => (
                  <tr key={index}>
                    <td>
                      <h4>
                        {item.clientname}
                        <br />
                        <span>{item.clientemail}</span>
                      </h4>
                    </td>
                  </tr>
                ))}
              </table>
            </div> */}
          </div>
        </div>
        {pop && (
          <div className="popupForm">
            <Client pop={pop} setPop={setPop} openpop={openpop} />
          </div>
        )}
      </div>
    </>
  );
};

export default Dashboard;
