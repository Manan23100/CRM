import React, { useEffect, useState } from "react";
import "./Allquote.css";
import axios from "axios";
import {
  Routes,
  Route,
  Navigate,
  Link,
  useNavigate,
  useLocation,
} from "react-router-dom";

const Allquote = () => {
  const location = useLocation();
  const path = location.pathname.split("/")[2];

  const [allqutaiondata, setallqutaiondata] = useState([]);
  const [quoteid, setquoteid] = useState(0);
  const [bool, setbool] = useState(false);
  console.log(allqutaiondata, "allquote");

  const nav = useNavigate();

  useEffect(() => {
    if (bool) {
      try {
        // return nav(`/BasicDetail/${quoteid}`);

        return nav(`/BasicDetail/${quoteid}`, {
          state: { clientid:path,  des: "Allquote" },
        });
      } catch (error) {
        console.log(error, "error");
      }
    }
  }, [bool]);

  useEffect(() => {
    const getalldata = async (req, res) => {
      try {
        const res = await axios.get(
          `http://localhost:2100/api/iternary/allquote/${path}`
        );
        setallqutaiondata(res.data.getall);
      } catch (error) {
        console.log(error, "error");

        return res.status(500).json({ message: "okok" });
      }
    };

    getalldata();
  }, [path]);

  return (
    <>
      <div className="quote">
        <div className="quote-table">
          <div className="alldiv">S.No.</div>
          <div className="alldiv">Name</div>
          <div className="alldiv">Destination</div>
          <div className="alldiv">Nights</div>
          <div className="alldiv">Days</div>
          <div className="alldiv">No. of Pax</div>
          <div className="alldiv">Cost</div>
          <div className="alldiv">use this</div>
        </div>
        <div className="quote-tables">
          {allqutaiondata.map((item, index) => (
            <div className="rowdirection">
              <div className="alldiv" key={index}>
                {index + 1}
              </div>
              <div className="alldiv">{item.clientname}</div>
              <div className="alldiv">{item.destination}</div>
              <div className="alldiv">{item.nights}</div>
              <div className="alldiv">{item.days}</div>
              <div className="alldiv">
                <div>
                  {item.adults + "A • "}
                  {item.children + "C"}
                </div>
              </div>
              <div className="alldiv">{item.finalprice}</div>
              <div
                className=" btn-use"
                onClick={() => (setquoteid(item._id), setbool(true))}
              >
                use this
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* {allqutaiondata.map((item, index) => (
          <div key={index}>{item.name}</div>
        ))} */}
    </>
  );
};

export default Allquote;
