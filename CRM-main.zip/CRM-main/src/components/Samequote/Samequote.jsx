import React, { useEffect, useState } from "react";
import "./Samequote.css";
import axios from "axios";
import {
  Routes,
  Route,
  Navigate,
  Link,
  useNavigate,
  useLocation,
} from "react-router-dom";

const Samequote = () => {
  const location = useLocation();
  const path = location.pathname.split("/")[2];

  const [che, setChe] = useState([]);
  const [savequtaiondata, setSavequtaiondata] = useState([]);
  const [samequoteid, setsamequoteid] = useState(0);
  const [bool, setbool] = useState(false);

  console.log(savequtaiondata, che, "okokoko");

  const nav = useNavigate();

  useEffect(() => {
    if (bool) {
      try {

        return nav(`/BasicDetail/${samequoteid}`, {
          state: { clientid: path, des: "Allquote" },
        });
      } catch (error) {
        console.log(error, "error");
      }
    }
  }, [bool]);

  useEffect(() => {
    const fecthdata = async () => {
      try {
        var arr = [];
        const res = await axios.post(
          "http://localhost:2100/api/client/getuserdetail",
          {
            id: path,
          }
        );
        arr.push(res.data.userdetail);

        const res1 = await axios.get(
          "http://localhost:2100/api/iternary/samequote"
        );

        const a = res1.data.quote;

        const lastarr = [];
        for (var i = 0; i < a.length; i++) {
          if (
            arr[0].destination === a[i].destination &&
            arr[0].days === a[i].days
          ) {
            lastarr.push(a[i]);
            return setSavequtaiondata(lastarr);
          } else if (
            arr[0].destination === a[i].destination ||
            arr[0].days === a[i].days
          ) {
            lastarr.push(a[i]);
            return setSavequtaiondata(lastarr);
          }
        }
      } catch (error) {
        console.log(error, "error");
      }
    };

    fecthdata();
  }, [path]);

  return (
    <>
      <div className="quote">
        <div className="quote-table">
          <div className="alldiv">S.No.</div>
          <div className="alldiv">Name</div>
          <div className="alldiv">Destination</div>
          <div className="alldiv">Nights</div>
          <div className="alldiv">Days</div>
          <div className="alldiv">No. of Pax</div>
          <div className="alldiv">Cost</div>
          <div className="alldiv">use this</div>
        </div>
        <div className="quote-tables">
          {savequtaiondata.map((item, index) => (
            <div className="rowdirection">
              <div className="alldiv" key={index}>
                {index + 1}
              </div>
              <div className="alldiv">{item.clientname}</div>
              <div className="alldiv">{item.destination}</div>
              <div className="alldiv">{item.nights}</div>
              <div className="alldiv">{item.days}</div>
              <div className="alldiv">
                <div>
                  {item.adults + "A • "}
                  {item.children + "C"}
                </div>
              </div>
              <div className="alldiv">{item.finalprice}</div>
              <div
                className=" btn-use"
                onClick={() => (setsamequoteid(item._id), setbool(true))}
              >
                use this
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Samequote;
