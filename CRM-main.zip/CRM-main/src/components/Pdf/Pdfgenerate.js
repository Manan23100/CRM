import React, { useRef, useState } from "react";
import { jsPDF } from "jspdf";
import Pdfstyle from "./Pdfstyle";
import html2canvas from "html2canvas";
import { Canvg, presets } from "canvg";
export default function Pdfgenerate() {
  const certificateTemplateRef = useRef(null);
  const preset = presets.offscreen();
  //         const handleGeneratePdf = async () => {
  //             const canvas = await html2canvas(certificateTemplateRef.current);
  //             const image = canvas.toDataURL("image/png", 1.0);
  //             console.log(image)
  //             const imgWidth = 628;
  // 			const pageHeight = 295;
  // 			const imgHeight = (canvas.height * imgWidth) / canvas.width;
  // 			const heightLeft = imgHeight;

  // //             var svg = document.getElementById('svg').innerHTML;
  // //             svg = svg.replace(/r?n|r/g, '').trim();
  // //             var canvas = document.createElement('canvas');
  // //   var context = canvas.getContext('2d');

  // //   context.clearRect(0, 0, canvas.width, canvas.height);
  // //   const v = await Canvg.from(context, svg, preset)

  // //   var imgData = canvas.toDataURL('image/png');

  // // const height2=canvas.height*pageWidth/canvas.width;

  // let height = 2000;
  // let width = certificateTemplateRef.current.style.width;

  //           const doc = new jsPDF({
  //             format: "a3",
  //             unit: "px"
  //           });
  //           width=  canvas.height,
  //         height= canvas.width;
  //           doc.addImage(image, 'PNG', 0, 0,imgWidth, imgHeight);

  //         //   // Adding the fonts
  //         //   doc.setFont("Anton-Regular", "normal");

  //               // save the document as a PDF with name of Memes
  //               doc.save("Memes");

  //         };
  const [showLoader, setLoader] = useState(false);

  const handleGeneratePdf = () => {
    window.scrollTo(0, 0);
    setTimeout(() => {
      setTimeout(() => {
        setLoader(true);
      }, 100);
      html2canvas(certificateTemplateRef.current).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const imgWidth = 190;
        const pageHeight = 290;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        const doc = new jsPDF("pt", "mm");
        let position = 0;
        doc.addImage(imgData, "PNG", 10, 0, imgWidth, imgHeight + 25);
        heightLeft -= pageHeight;
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          doc.addPage();
          doc.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight + 25);
          heightLeft -= pageHeight;
        }
        doc.save("download.pdf");
        setLoader(false);
      });
    }, 1000);
  };

  return (
    <div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        <button
          style={{
            margin: "50px",
            padding: "10px",
            backgroundColor: "black",
            color: "white",
            fontFamily: "Anton",
            fontSize: "1.2rem",
            textTransform: "uppercase",
            letterSpacing: "0.1rem",
            cursor: "pointer",
            width: "200px",
          }}
          onClick={handleGeneratePdf}
        >
          Generate Pdf
        </button>
        <div ref={certificateTemplateRef}>
          <Pdfstyle />
          {/* <ContentTemplate /> */}
        </div>
      </div>
    </div>
  );
}
