import React from "react";
import Itinerarycompo from "../itineraryCompo/Itinerarycompo";
// import { BsFillSunFill } from "react-icons/bs";
import "./Itinenary.css";
import Miscellaneous from "../miscellaneous/Miscellaneous";
import { useState } from "react";
import { BsFillSunFill } from "react-icons/bs";

const Itinerary = () => {
  const [addIternary, setAddIternary] = useState([{}]);

  const handleAdd = (e) => {
    e.preventDefault();
    setAddIternary([...addIternary, {}]);
  };

  return (
    <>
      <div className="itineraryArea">
        <div className="itinerary">
          <div>
            <BsFillSunFill />
            <span>Day Wise Itinerary</span>
          </div>
          <hr />
        </div>
      </div>
      {addIternary.map((data, index) => (
        <Itinerarycompo {...data} />
      ))}
      <div className="dayBtn">
        <button className="moreBtn" onClick={handleAdd}>
          Add More Days
        </button>
      </div>
      {/* <div className="dayBtn">
        <button className="moreBtn">Remove Days</button>
      </div> */}
      {/* <Miscellaneous /> */}
    </>
  );
};

export default Itinerary;
