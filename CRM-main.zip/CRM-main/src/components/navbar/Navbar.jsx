import React from "react";
import "./Navbar.css";
import { Link } from "react-router-dom";
import { BiBookBookmark } from "react-icons/bi";


const Navbar = () => {
  return (
    <>
      <div className="navbars1">
        <BiBookBookmark className="firstLogo" />
        <div className="navContainers">
          <Link to="/" style={{ color: "inherit", textDecoration: "none" }}>
            <span className="logos">Holidays Crowd</span>
          </Link>
          <div className="navItems">
            <Link to="/home" className="navButtons">
              Home
            </Link>
            <Link to="/login" className="navButtons">
              LogIn
            </Link>
            <Link to="/signup" className="navButtons">
              SignUp
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
