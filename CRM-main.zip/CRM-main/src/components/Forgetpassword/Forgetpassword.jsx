import React, { useContext, useState } from "react";
import Navbar from "../navbar/Navbar";
import axios from "axios";
import "./Forgetpassword.css";

const Forgetpassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const handlenum = async (e) => {
    e.preventDefault();
    if (!email) {
      alert("plese enter email first");
    } else {
      console.log(email);
      const res = await axios.post(
        "http://localhost:2100/api/users/getuserusingemail",
        {
          email,
        }
      );

      console.log(res, "res");
      const data = await axios.post("http://localhost:2100/api/email/reset", {
        send_to: email,
        msg: `http://localhost:3000/resetpassword/${res.data.user._id}`,
      });

      console.log(data, "data");
      if (data) {
        setMessage("Send successfully! please check your mail");
      }
    }
  };
  return (
    <>
      <Navbar />
      <div className="Conainer-head">
        <h1>Forgot password</h1>
        <h4>No worries we are here for you</h4>
      </div>
      <div className="container-forget">
        {message ? (
          <div className="msg-class">{message}</div>
        ) : (
          <div className="forget-box">
            <input
              onChange={(e) => {
                setEmail(e.target.value);
              }}
              className="input-email"
              value={email}
              type="email"
              placeholder="please enter your email"
            />

            <button className="btn-forget" onClick={handlenum}>
              Send Reset Link
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default Forgetpassword;
