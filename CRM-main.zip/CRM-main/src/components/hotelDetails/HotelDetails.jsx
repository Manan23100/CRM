import React, { useState } from "react";
// import { MdFlight } from "react-icons/md";
// import { AiFillCar } from "react-icons/ai";
import "./hotelDetails.css";
import IncExc from "../IncExc/IncExc";
import MiddleComp from "../middleComponent/MiddleComp";
import { FaBed } from "react-icons/fa";

// import { FaBed } from "react-icons/fa";

const HotelDetails = ({ days, inputFields, setInputFields }) => {
  // const [travel, setTravel] = useState({
  //   flight: "",
  //   cab: "",
  // });
  // console.log(travel);
  // const [flight, setFlight] = useState("");
  // console.log(flight);
  // const [cab, setCab] = useState("");
  // console.log(cab);

  // const [showF, setShowF] = useState(true);
  // const openF = () => {
  //   setShowF(!showF);
  // };

  // const [showC, setShowC] = useState(true);
  // const openC = () => {
  //   setShowC(!showC);
  // };

  const handleAdd = (e) => {
    e.preventDefault();
    setInputFields([
      ...inputFields,
      {
        nights: "",
        hotelname: "blank",
        cityname: "",
        category: "",
        roomtype: "",
        comments: "",
      },
    ]);
  };

  const handleSave = () => {
    let arr = inputFields;
    setInputFields(arr);
    console.log("running", inputFields);
  };

  return (
    <>
      <div className="hotelled">
        <div className="bed">
          <div>
            <FaBed />
            <span
              onClick={() => {
                console.log(inputFields);
              }}
            >
              Hotel Details
            </span>
          </div>
        </div>
        {/* <div className="hotelNot">
            <input type="checkbox" id="hotelNot" name="hotelNot" value="" />
            <label htmlFor="vehicle1" id="hotelNot">
              Hotel not included
            </label>
          </div> */}
        <hr />
      </div>
      {inputFields.map((data, index) => {
        return <MiddleComp data={data} days={days} />;
      })}
      <div className="simiBtn">
        <button className="addBtn" onClick={handleAdd}>
          Save hotel
        </button>
        {/* <button className="addBtn" onClick={handleSave}>
          Save details
        </button> */}
      </div>

      {/* flight details */}

      {/* <div className="flightD">
        <div className="flight">
          <div>
            <MdFlight />
            <span>Flight Details</span>
          </div>
          <div onClick={openF} className="flightNot">
            <input type="checkbox" id="flightNot" name="flightNot" value="" />
            <label htmlFor="flight" id="flightNot">
              Flight not included
            </label>
          </div>
        </div>
        <hr className="hrfd" />
        {showF && (
          <>
            <div className="enterD">
              <form>
                <label>
                  <textarea
                    value={travel.flight}
                    name="comment"
                    form="usrform"
                    id="flight"
                    placeholder="Enter flight details"
                    onChange={(e) =>
                      setTravel((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                  ></textarea>
                </label>
              </form>
            </div>
            <div>
              <form>
                <label htmlFor="myfile" className="sfiles">
                  Select files:
                </label>
                <input type="file" id="myfile" name="myfile" multiple />
              </form>
            </div>
          </>
        )}
      </div> */}

      {/* busses details */}

      {/* <div className="cabD">
        <div className="cab">
          <div>
            <AiFillCar />
            <span>Cab Details</span>
          </div>
          <div onClick={openC} className="cabNot">
            <input type="checkbox" id="cabNot" name="cabNot" value="" />
            <label htmlFor="cab" id="cabNot">
              Cab not included
            </label>
          </div>
        </div>
        <hr />
        {showC && (
          <>
            <div className="enterD">
              <form>
                <label>
                  <textarea
                    value={travel.cab}
                    name="comment"
                    form="usrform"
                    id="cab"
                    placeholder="Enter cab details"
                    onChange={(e) =>
                      setTravel((prev) => ({
                        ...prev,
                        [e.target.id]: e.target.value,
                      }))
                    }
                  ></textarea>
                </label>
              </form>
            </div>
          </>
        )}
      </div> */}
      {/* <IncExc days={days} /> */}
    </>
  );
};

export default HotelDetails;
