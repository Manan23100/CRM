import React, { useContext, useState, useLocation } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../navbar/Navbar";
import axios from "axios";
import "./Resetpassword.css";
import { AiFillEyeInvisible, AiFillEye } from "react-icons/ai";

const Resetpassword = () => {
  const nav = useNavigate();
  const [pass, setPass] = useState("");
  const [cnfpass, setCnfpass] = useState("");

  const [passtype, setPasstype] = useState(false);
  const path = useParams();
  const handlepass = async (e) => {
    e.preventDefault();
    if (pass !== cnfpass) {
      alert("plese enter Password Again");
      return window.location.reload(true);
    } else if (pass === cnfpass) {
      const res = await axios.post(
        "http://localhost:2100/api/auth/updatepassword",
        {
          pass,
          id: path.id,
        }
      );
      console.log(res, "res");

      return nav("/dashboard");
    }
  };
  return (
    <>
      <Navbar />
      <div className="container-forget">
        <div className="forget-box">
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-start",
            }}
            className="eye-btn"
          >
            <input
              onChange={(e) => {
                setPass(e.target.value);
              }}
              className="input-pass"
              value={pass}
              type={passtype ? "text" : "password"}
              placeholder="please enter Password"
            />
            <div onClick={() => setPasstype(!passtype)}>
              {passtype ? <AiFillEyeInvisible /> : <AiFillEye />}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              paddingRight: "30px",
            }}
            className="eye-btn"
          >
            <input
              onChange={(e) => {
                setCnfpass(e.target.value);
              }}
              className="input-pass"
              value={cnfpass}
              type="password"
              placeholder="please Re-enter your password"
            />
          </div>

          <button className="btn-forget" onClick={handlepass}>
            Submit
          </button>
        </div>
      </div>
    </>
  );
};

export default Resetpassword;
