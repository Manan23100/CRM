import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Sidebar.css";
import axios from "axios";
import Cookies from "universal-cookie";

let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
  });
  this.classList.add("hovered");
}

list.forEach((item) => item.addEventListener("mouseover", activeLink));

const Sidebar = () => {

  const nav = useNavigate();
  const handle = async () => {
    
  
      try {
        const cookies = new Cookies();
        cookies.remove("Token");
      
        return nav("/login");
      } catch (error) {
        console.log(error);
      }
    
  };
  return (
    <>
      <div class="navigation">
        <ul>
          <li>
            <Link to="/">
              <span class="icon">
                <ion-icon name="logo-apple"></ion-icon>
              </span>
              <span class="title">Holidays Crowd</span>
            </Link>
          </li>

          <li>
            <Link to="/dashboard">
              <span class="icon">
                <ion-icon name="home-outline"></ion-icon>
              </span>
              <span class="title dashtitle">Dashboard</span>
            </Link>
          </li>

          <li>
            <div className="signout">
              <span class="icon">
                <ion-icon name="log-out-outline"></ion-icon>
              </span>
              <span class="title_signout" onClick={handle}>Sign Out</span>
            </div>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Sidebar;
