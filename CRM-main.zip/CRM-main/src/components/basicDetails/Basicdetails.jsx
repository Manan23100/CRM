import React, { useState, useRef } from "react";
import "./basicDetails.css";
import axios from "axios";
import {
  Routes,
  Route,
  Navigate,
  Link,
  useNavigate,
  useLocation,
} from "react-router-dom";
import { CiMemoPad } from "react-icons/ci";
import { AiOutlinePlus } from "react-icons/ai";
import { FaRupeeSign } from "react-icons/fa";
import { TbEqual } from "react-icons/tb";
import HotelDetails from "../hotelDetails/HotelDetails";
import DatePicker from "react-datepicker";
import Cookies from "universal-cookie";
import { jsPDF } from "jspdf";
import Pdfstyle from "../Pdf/Pdfstyle";
import html2canvas from "html2canvas";

// import MyDocument from "../../pages/pdf";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
} from "@react-pdf/renderer";
import sikkim from "../../sikkim.png";
import { PDFDownloadLink } from "@react-pdf/renderer";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import Sidebar from "../sideComponent/Sidebar";
import { useEffect } from "react";
import IncExc from "../IncExc/IncExc";
import Itinerary from "../itinerary/Itinerary";
import Miscellaneous from "../miscellaneous/Miscellaneous";

const styles = StyleSheet.create({
  page: {
    padding: 50,
    paddingTop: 70,
  },
  section: {
    flexGrow: 3,
  },
  image: {
    width: "100%",
    height: "50%",
    display: "flex",
    objectFit: "cover",
  },
});

const Basicdetails = () => {
  const [include, setInclude] = useState({
    breakfast: false,
    lunch: false,
    dinner: false,
    showComment: "",
    flight: false,
    showF: "",
    train: false,
    showT: "",
    bus: false,
    showB: "",
    suvCab: false,
    smallCab: false,
    sedanCab: false,
    acCab: false,
    nonAcCab: false,
    showComment2: "",
    eveningCruise: false,
    jeepSafari: false,
    elephantSafari: false,
    showComment3: "",
    homeStay: false,
    budgetHotel: false,
    threeStarHotel: false,
    fourStarHotel: false,
    fiveStarHotel: false,
    sharingHouseboat: false,
    pvtHouseboat: false,
    budgetHouseboat: false,
    premiumHouseboat: false,
    luxuryHouseboat: false,
    showComment4: "",
  });

  const location = useLocation();
  console.log(location);
  const path = location.pathname.split("/")[2];

  //om changes
  const certificateTemplateRef = useRef(null);

  const [price, setPrice] = useState(0);

  const [inputFields, setInputFields] = useState([
    {
      nights: "",
      hotelname: "",
      cityname: "",
      category: "",
      roomtype: "",
      comments: "",
    },
  ]);

  console.log(location);

  const [name, setName] = useState();

  useEffect(() => {
    const getdata = async () => {
      try {
        if (location.state.des === "dashboard") {
          const res = await axios.post(
            "http://localhost:2100/api/client/getuserdetail",
            {
              id: path,
            }
          );

          console.log(res.data.userdetail, "res");
          setseleect(res.data.userdetail.Status);
          setBasicDetails({
            ...basicDetails,
            name: res.data.userdetail.clientname,
            destination: res.data.userdetail.destination,
            // startDate: res.data.userdetail.startDate,
            days: res.data.userdetail.days,
            adults: res.data.userdetail.adults,
            children: res.data.userdetail.children,
            nights: res.data.userdetail.days - 1,
          });
        } else if (location.state.des === "Allquote") {
          console.log(path);
          const res = await axios.post(
            "http://localhost:2100/api/iternary/getitenary",
            {
              id: path,
            }
          );

          console.log(res.data.getall[0], "res");
           setseleect(res.data.getall[0].Status);
           setBasicDetails({
             ...basicDetails,
             name: res.data.getall[0].clientname,
             destination: res.data.getall[0].destination,
             // startDate: res.data.userdetail.startDate,
             days: res.data.getall[0].days,
             adults: res.data.getall[0].adults,
             children: res.data.getall[0].children,
             nights: res.data.getall[0].days - 1,
             fligtcost: res.data.getall[0].flightcost,
             finalprice: res.data.getall[0].finalprice,
             visacost: res.data.getall[0].visacost,
             pacakgecost: res.data.getall[0].packagecost,
             markup: res.data.getall[0].markup,
             gst: res.data.getall[0].gst,
           });
        }
      } catch (error) {
        console.log(error, "error");
      }
    };
    getdata();
  }, [location]);

  const cookies = new Cookies();
  const Token = cookies.get("Token");

  const [basicDetails, setBasicDetails] = useState({
    name: "",
    destination: "",
    startDate: new Date(),
    endDate: new Date(),
    days: "",
    nights: "",
    adults: "",
    children: "",
    fligtcost: "",
    visacost: "",
    pacakgecost: "",
    markup: "",
    gst: "",
    finalprice: "",
  });
  console.log(basicDetails);

  const navigate = useNavigate();
  const allquote = async () => {

  
    try {
       if (location.state.des === "dashboard") {
      return navigate(`/allquote/${path}`);
       }
        else if (location.state.des === "Allquote") {
          return navigate(`/allquote/${location.state.clientid}`);
        }
    } catch (error) {
      console.log(error, "error");
    }
  };


   const samequote = async () => {
     try {
       if (location.state.des === "dashboard") {
         return navigate(`/samequote/${path}`);
       } else if (location.state.des === "Allquote") {
         return navigate(`/samequote/${location.state.clientid}`);
       }
     } catch (error) {
       console.log(error, "error");
     }
   };


  const [seleect, setseleect] = useState();

  const handleupdate = async () => {
    try {
      const res = await axios.put(
        "http://localhost:2100/api/client/updateclient",
        {
          id: path,
          basicDetails,
          Status: seleect,
        }
      );
      return window.location.reload(true);
    } catch (error) {
      console.log(error);
    }
  };

  // const [days, setDays] = useState();

  // const [Destination, setDestination] = useState(

  // );
  // const [date, setDate] = useState();
  // const [adults, setAdults] = useState();
  // const [children, setChildren] = useState();
  // const [fligtcost, setFligtcost] = useState("");
  // const [visacost, setVisacost] = useState(0);
  // const [pacakgecost, setPackagecost] = useState(0);
  // const [markup, setMarkup] = useState(0);
  // const [gst, setGst] = useState(0);
  const total = parseInt(
    parseInt(basicDetails.visacost) +
      parseInt(basicDetails.pacakgecost) +
      parseInt(basicDetails.markup)
  );
  const withoutflight = total + (total * basicDetails.gst) / 100;
  const totalprice = parseInt(basicDetails.fligtcost) + withoutflight;

  console.log("basicDetails:", basicDetails);
  const [showLoader, setLoader] = useState(false);

  const [packageDetails, setPackageDetails] = useState({
    name: "",
    destination: "",
    startDate: new Date(),
    endDate: new Date(),
    days: "",
    nights: "",
    adults: "",
    children: "",
    fligtcost: "",
    visacost: "",
    pacakgecost: "",
    markup: "",
    gst: "",
    finalprice: "",
  });

  const MyDocument = () => {
    return (
      <>
        <Document>
          <Page size="A4" style={styles.page}>
            <Image style={styles.image} src={sikkim} />
            <View style={styles.section}>
              <Text>Dear {basicDetails.name} </Text>
              <Text>Greetings from HOLIDAYS CROWD </Text>
              <Text>
                Thank you for allowing us the opportunity to serve you. Here are
                the confirmed quote details for your reference. Please feel free
                to contact us for any queries.
              </Text>
            </View>
            <View style={styles.section}>
              <Text>Destination</Text>
              <Text>{basicDetails.destination}</Text>
            </View>
            <View style={styles.section}>
              <Text>Duration</Text>
              <Text>{basicDetails.days}</Text>
            </View>
            <View style={styles.section}>
              <Text>Adults</Text>
              <Text>{basicDetails.adults}</Text>
            </View>
            <View style={styles.section}>
              <Text>Quotation Price</Text>

              <Text>{basicDetails.totalprice}</Text>
            </View>
            <View style={styles.section}></View>
          </Page>
        </Document>
      </>
    );
  };

  const handleGeneratePdf = () => {
    if (inputFields.length % 6 !== 0) {
      const diff = 6 - (inputFields.length % 6);
      let arr = inputFields;

      for (let index = 0; index < diff; index++) {
        arr.push({ hotelname: "blank" });
      }
      setInputFields(arr);
    }

    window.scrollTo(0, 0);
    setTimeout(() => {
      setTimeout(() => {
        setLoader(true);
      }, 200);
      html2canvas(certificateTemplateRef.current).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const imgWidth = 190;
        const pageHeight = 290;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        const doc = new jsPDF("pt", "mm");
        let position = 0;
        doc.addImage(imgData, "PNG", 10, 0, imgWidth, imgHeight + 25);
        heightLeft -= pageHeight;
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          doc.addPage();
          doc.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight + 25);
          heightLeft -= pageHeight;
        }
        doc.save("download.pdf");
        setLoader(false);
      });
    }, 2000);
  };

  return !Token ? (
    <Navigate to="/login" />
  ) : (
    <>
      <Sidebar />

      <div className="container">
        <div className="navbars">
          <div className="navContainerr">
            {/* <span className="logot">Holidays Crowd</span> */}
            <div className="navItems">
              <button className="navButton" onClick={allquote}>
                All Quotation
              </button>
              <button className="navButton">EDIT TTSN</button>
              <button className="navButton" onClick={samequote}>
                Same Qute
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="headerListItemm">
        <div className="bd-container">
          <span className="bd">Basic Details</span>
          <div className="bd">
            <div class="selectBox">
              <select
                value={seleect}
                onChange={(e) => {
                  setseleect(e.target.value);
                }}
              >
                <option vlaue="New Lead">New Lead</option>
                <option value="Converted">Converted</option>
                <option value="Past-Trip">Past-Trip</option>
                <option value="On-Trip">On-Trip</option>
                <option value="InProgress">InProgress</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>
          {/* <div className="bd" onClick={"handlestatus"}>
            Status
          </div> */}
        </div>

        <hr />
        <div>
          <form className="daynightt">
            <div className="firstDiv">
              <div className="daye">
                <label htmlFor="days">Name</label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.name}
                  type="text"
                  id="name"
                  className="fname"
                  name="Name"
                  placeholder="enter name here"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="firstDiv">
              <div className="night">
                <label htmlFor="nights">Destination</label>
                <br />
              </div>
              <div className="nightInput">
                <input
                  value={basicDetails.destination}
                  type="text"
                  id="destination"
                  className="fname"
                  placeholder="destination"
                  name="Destination"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
              </div>
            </div>
            <div className="firstDiv">
              <div className="night">
                <label htmlFor="nights">Start Date</label>
                <br />
              </div>
              <div className="nightInput">
                <DatePicker
                  selected={basicDetails.startDate}
                  id="startdate"
                  className="fname"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      startDate: e,
                    }))
                  }
                />
              </div>
            </div>
            <div className="firstDiv">
              <div className="night">
                <label htmlFor="nights">End Date</label>
                <br />
              </div>
              <div className="nightInput">
                <DatePicker
                  className="fname"
                  id="endDate"
                  selected={basicDetails.endDate}
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      endDate: e,
                    }))
                  }
                />
              </div>
            </div>
          </form>
        </div>
        <div>
          <form className="daynighttt">
            <div className="ninput">
              <div className="daye">
                <label htmlFor="days">Days</label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.days}
                  type="number"
                  id="days"
                  className="fname"
                  name="day"
                  placeholder="enter days here"
                  onChange={(e) => {
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }));
                  }}
                />
                <br />
              </div>
            </div>
            <div className="ninput">
              <div className="night">
                <label htmlFor="nights">Nights</label>
                <br />
              </div>
              <div className="nightInput">
                <input
                  value={
                    basicDetails.days >= 1
                      ? basicDetails.days - 1
                      : basicDetails.days
                  }
                  type="number"
                  id="nights"
                  className="fname"
                  name="day"
                  placeholder="enter nights here"
                />
              </div>
            </div>
            <div className="ninput">
              <div className="night">
                <label htmlFor="nights">Adults</label>
                <br />
              </div>
              <div className="nightInput">
                <input
                  value={basicDetails.adults}
                  type="number"
                  id="adults"
                  className="fname"
                  name="Passanger"
                  placeholder="no. of passanger"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
              </div>
            </div>
            <div className="ninput">
              <div className="night">
                <label htmlFor="nights">Children</label>
                <br />
              </div>
              <div className="nightInput">
                <input
                  value={basicDetails.children}
                  type="number"
                  id="children"
                  className="fname"
                  name="Passanger"
                  placeholder="no. of passanger"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
              </div>
              <div className="btn-update" onClick={handleupdate}>
                update userdetails
              </div>
            </div>
          </form>
        </div>

        <div>
          <form className="rupee">
            <div className="perperson">
              <FaRupeeSign />
              <span className="cc">Costing</span>
              <input type="checkbox" id="perperson" name="perperson" value="" />
              <label htmlFor="vehicle1" className="perper">
                {" "}
                Per Person
              </label>
              <hr />
            </div>
          </form>
        </div>
        <div className="quotation">
          <form className="quotationPrices">
            <div className="priceD">
              <div className="dayy fday">
                <label htmlFor="days" className="a">
                  Flight Cost
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.fligtcost}
                  type="number"
                  id="fligtcost"
                  className="fcost"
                  name="day"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="plus">
              <AiOutlinePlus />
            </div>
            <div>
              <div className="dayy fday">
                <label htmlFor="days" className="b">
                  Visa Cost
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.visacost}
                  type="number"
                  id="visacost"
                  className="vcost"
                  name="day"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="plus">
              <AiOutlinePlus />
            </div>
            <div>
              <div className="dayy fday">
                <label htmlFor="days" className="c">
                  Land Package Cost
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.pacakgecost}
                  type="number"
                  id="pacakgecost"
                  className="lpcost"
                  name="day"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="plus">
              <AiOutlinePlus />
            </div>
            <div>
              <div className="dayy fday">
                <label htmlFor="days" className="d">
                  Markup
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.markup}
                  type="number"
                  id="markup"
                  className="markup"
                  name="day"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="plus">
              <AiOutlinePlus />
            </div>
            <div>
              <div className="dayy fday">
                <label htmlFor="days" className="e">
                  GST%
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={basicDetails.gst}
                  type="number"
                  id="gst"
                  className="gst"
                  name="day"
                  onChange={(e) =>
                    setBasicDetails((prev) => ({
                      ...prev,
                      [e.target.id]: e.target.value,
                    }))
                  }
                />
                <br />
              </div>
            </div>
            <div className="equal">
              <TbEqual />
            </div>
            <div>
              <div className="dayy fday">
                <label htmlFor="days" className="f">
                  Final Price
                </label>
                <br />
              </div>
              <div className="dayInputt">
                <input
                  value={totalprice}
                  type="number"
                  id="totalP"
                  className="qprice"
                  name="day"
                  onChange={(e) => {
                    setPrice(e.target.value);
                  }}
                />
                <br />
              </div>
            </div>
          </form>
        </div>
      </div>

      <HotelDetails
        inputFields={inputFields}
        setInputFields={setInputFields}
        days={basicDetails.days}
      />
      <IncExc
        include={include}
        setInclude={setInclude}
        days={basicDetails.days}
      />
      <Itinerary days={basicDetails.days} />
      <Miscellaneous />

      <div filename="FORM">
        <span className="btnD">
          <button onClick={handleGeneratePdf} className="button cancel-btn">
            Download PDF
          </button>
        </span>
      </div>

      <div ref={certificateTemplateRef}>
        <Pdfstyle
          include={include}
          price={price}
          basicDetails={basicDetails}
          inputFields={inputFields}
        />
        {/* <ContentTemplate /> */}
      </div>
    </>
  );
};

export default Basicdetails;
