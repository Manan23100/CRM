import React, { useState } from 'react'
import styles from './Pdfstyle.module.css'
import Dubai from '../destinationpage/LongCarousel/images/Thailand.png'
import dal from './dal.jpg'
export default function Pdfstyle({ activity, setHotels,hotels}) {



  return (
    <div className={styles.mainCont}>

        <div className={styles.header}>
            <div className={styles.companyLogo}></div>
            <div className={styles.aboutCompany}>
                <div className={styles.companyName}>THOMAS COOK</div>
                <div className={styles.lightText}>TRAVEL AGENCY / AGENT</div>
                <div className={styles.phoneCont}><svg width="13" height="13" style={{marginRight:'5px',marginBottom:'-1px'}} viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12.57 10.0206L10.611 9.79694C10.1406 9.74295 9.67784 9.90491 9.34621 10.2365L7.92715 11.6556C5.74456 10.545 3.9553 8.76349 2.84472 6.57319L4.2715 5.14641C4.60313 4.81478 4.76509 4.35204 4.71111 3.88159L4.48745 1.93808C4.3949 1.15913 3.73935 0.572998 2.9527 0.572998H1.61846C0.746971 0.572998 0.0220127 1.29796 0.075999 2.16945C0.484752 8.75577 5.75227 14.0156 12.3309 14.4243C13.2024 14.4783 13.9273 13.7534 13.9273 12.8819V11.5476C13.935 10.7687 13.3489 10.1131 12.57 10.0206Z" fill="#1A1A1A"/>
                    </svg>
                    1800 209 9100</div>
                    <div className={styles.phoneCont}><svg width="13" height="13" style={{marginRight:'5px',marginBottom:'0px'}} viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15.8966 9.06833C16.2371 4.24604 12.2541 0.263091 7.43184 0.603581C3.24302 0.888642 0.0835827 4.54693 0.0835825 8.74367L0.0835824 11.6656C0.0835824 12.1011 0.439909 12.4574 0.87542 12.4574C1.31093 12.4574 1.66726 12.1011 1.66726 11.6656L1.66726 8.75951C1.66726 5.80596 3.58351 3.09787 6.44204 2.36146C11.0347 1.18162 15.3185 5.45755 14.1308 10.0502C13.4023 12.9167 10.6942 14.8329 7.74066 14.8329L6.86963 14.8329C6.24408 14.8329 5.62645 14.2707 5.62645 13.6452C5.62645 13.0196 6.24408 12.4574 6.86963 12.4574L7.85943 12.4574C9.84694 12.4574 11.6365 11.0479 11.9136 9.08416C12.3016 6.39192 9.97364 4.11934 7.26555 4.60236C5.75314 4.87159 4.50204 6.05143 4.14571 7.548C3.80522 9.00498 4.27241 10.3907 5.19886 11.3013C4.23281 12.006 3.72604 13.4155 4.24073 14.7062C4.66041 15.7673 5.74522 16.4166 6.88547 16.4166L7.74857 16.4166C11.9532 16.4166 15.6115 13.2572 15.8966 9.06833ZM5.62645 8.4982C5.62645 7.18375 6.68751 6.12269 8.00196 6.12269C9.31641 6.12269 10.3775 7.18375 10.3775 8.4982C10.3775 9.81266 9.31641 10.8737 8.00196 10.8737C6.68751 10.8737 5.62645 9.81266 5.62645 8.4982Z" fill="#1A1A1A"/>
                    </svg>traveline@.thomascook.com</div>
                </div>

        </div>

        <div className={styles.packageCont}>
            <div className={styles.imageCont}>
                <img src={dal.src}  style={{objectFit:"contain",height:'100%',width:'100%'}}/>
            </div>

            <div className={styles.packageNameCont}>
                <div className={styles.packageName}>
                    North East Package
                    <div className={styles.lightText}>4N / 5D  -  2 ADULTS  -  1 ROOM</div>
                </div>
                <div className={styles.packagePrice}>
                    ₹ 50,000/-
                    <div className={styles.lightText} style={{marginTop:'1px'}}>per person inclusive of all taxes</div>
                </div>
                
            </div>

            <div className={styles.packageDateCont}>
                <div className={styles.singleDate} style={{borderRight:'1px solid black', marginRight:'0px'}}>Start Date : 26 JAN 2023</div>
                <div className={styles.singleDate} style={{textAlign:'right',marginLeft:'0px'}}>End Date : 31 JAN 2023</div>
            </div>

            <div className={styles.includions}>
                <div className={styles.inclusionBox}>INC<br></br> LUS<br></br> ION</div>
                <div className={styles.inclusionDetail}>

                    <div className={styles.singleDetail}>
                    <svg style={{marginRight:'12px'}}  width="40" height="26" viewBox="0 0 38 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.86692 32.6904C2.45909 32.6904 2.12184 32.557 1.85517 32.2904C1.58851 32.0237 1.45518 31.6864 1.45518 31.2786C1.45518 30.8708 1.58851 30.5335 1.85517 30.2669C2.12184 30.0002 2.45909 29.8669 2.86692 29.8669H33.9253C34.3332 29.8669 34.6704 30.0002 34.9371 30.2669C35.2037 30.5335 35.3371 30.8708 35.3371 31.2786C35.3371 31.6864 35.2037 32.0237 34.9371 32.2904C34.6704 32.557 34.3332 32.6904 33.9253 32.6904H2.86692ZM5.45512 22.6199C5.1414 22.714 4.83553 22.6983 4.53749 22.5728C4.23945 22.4474 4.01201 22.2434 3.85515 21.9611L0.325783 15.9376C0.106179 15.5926 0.0669634 15.2631 0.208138 14.9494C0.349312 14.6357 0.623818 14.4475 1.03166 14.3847C1.18852 14.3534 1.36106 14.369 1.5493 14.4318C1.73753 14.4945 1.89439 14.573 2.01988 14.6671L4.89043 17.2082L15.5256 14.3377L8.46685 2.52606C8.1845 2.05548 8.1296 1.60059 8.30214 1.16138C8.47469 0.722169 8.82763 0.424134 9.36095 0.267273C9.61193 0.204529 9.87859 0.204529 10.1609 0.267273C10.4433 0.330017 10.6786 0.43982 10.8668 0.59668L23.6196 12.1259L33.7841 9.39656C34.6312 9.14558 35.3998 9.2946 36.09 9.84361C36.7802 10.3926 37.1253 11.122 37.1253 12.0318C37.1253 12.6279 36.9449 13.1612 36.5841 13.6318C36.2233 14.1024 35.7606 14.4161 35.1959 14.573L5.45512 22.6199Z" fill="#1A1A1A"/>
                        </svg>
                        <div style={{marginTop:'5px'}}>
                        HOTELS
                        </div>
                    </div>
                    <div className={styles.singleDetail}>
                        <svg style={{marginRight:'12px'}}  width="37" height="32" viewBox="0 0 38 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.86692 32.6904C2.45909 32.6904 2.12184 32.557 1.85517 32.2904C1.58851 32.0237 1.45518 31.6864 1.45518 31.2786C1.45518 30.8708 1.58851 30.5335 1.85517 30.2669C2.12184 30.0002 2.45909 29.8669 2.86692 29.8669H33.9253C34.3332 29.8669 34.6704 30.0002 34.9371 30.2669C35.2037 30.5335 35.3371 30.8708 35.3371 31.2786C35.3371 31.6864 35.2037 32.0237 34.9371 32.2904C34.6704 32.557 34.3332 32.6904 33.9253 32.6904H2.86692ZM5.45512 22.6199C5.1414 22.714 4.83553 22.6983 4.53749 22.5728C4.23945 22.4474 4.01201 22.2434 3.85515 21.9611L0.325783 15.9376C0.106179 15.5926 0.0669634 15.2631 0.208138 14.9494C0.349312 14.6357 0.623818 14.4475 1.03166 14.3847C1.18852 14.3534 1.36106 14.369 1.5493 14.4318C1.73753 14.4945 1.89439 14.573 2.01988 14.6671L4.89043 17.2082L15.5256 14.3377L8.46685 2.52606C8.1845 2.05548 8.1296 1.60059 8.30214 1.16138C8.47469 0.722169 8.82763 0.424134 9.36095 0.267273C9.61193 0.204529 9.87859 0.204529 10.1609 0.267273C10.4433 0.330017 10.6786 0.43982 10.8668 0.59668L23.6196 12.1259L33.7841 9.39656C34.6312 9.14558 35.3998 9.2946 36.09 9.84361C36.7802 10.3926 37.1253 11.122 37.1253 12.0318C37.1253 12.6279 36.9449 13.1612 36.5841 13.6318C36.2233 14.1024 35.7606 14.4161 35.1959 14.573L5.45512 22.6199Z" fill="#1A1A1A"/>
                        </svg>
                        <div style={{marginTop:'8px'}}>
                        Flights
                        </div>
                    </div>

                    <div className={styles.singleDetail}>
                        <svg style={{marginRight:'12px'}}  width="39" height="35" viewBox="0 0 39 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.46265 14.0878C1.04015 14.0878 0.690778 13.9497 0.414528 13.6735C0.138278 13.3972 0.000152588 13.0478 0.000152588 12.6253V12.1378C0.000152588 8.59533 1.7064 5.74346 5.1189 3.58221C8.5314 1.42096 13.3252 0.340332 19.5002 0.340332C25.6752 0.340332 30.4689 1.42096 33.8814 3.58221C37.2939 5.74346 39.0002 8.59533 39.0002 12.1378V12.6253C39.0002 13.0478 38.862 13.3972 38.5858 13.6735C38.3095 13.9497 37.9602 14.0878 37.5377 14.0878H1.46265ZM3.02265 11.1628H35.9777C35.8802 8.92033 34.312 7.04346 31.2733 5.53221C28.2345 4.02096 24.3102 3.26533 19.5002 3.26533C14.6902 3.26533 10.7495 4.02096 7.67828 5.53221C4.60703 7.04346 3.05515 8.92033 3.02265 11.1628ZM0.000152588 21.0103C0.000152588 20.7178 0.113902 20.4335 0.341403 20.1572C0.568902 19.881 0.861403 19.6616 1.2189 19.4991C1.9664 19.2391 2.70578 18.8572 3.43703 18.3535C4.16828 17.8497 5.23265 17.5978 6.63015 17.5978C8.38515 17.5978 9.54703 17.9553 10.1158 18.6703C10.6845 19.3853 11.6352 19.7428 12.9677 19.7428C14.3002 19.7428 15.2833 19.3853 15.917 18.6703C16.5508 17.9553 17.7452 17.5978 19.5002 17.5978C21.2552 17.5978 22.4495 17.9553 23.0833 18.6703C23.717 19.3853 24.7002 19.7428 26.0327 19.7428C27.3652 19.7428 28.3158 19.3853 28.8845 18.6703C29.4533 17.9553 30.6152 17.5978 32.3702 17.5978C33.7677 17.5978 34.832 17.8497 35.5633 18.3535C36.2945 18.8572 37.0339 19.2391 37.7814 19.4991C38.1389 19.6616 38.4314 19.8728 38.6589 20.1328C38.8864 20.3928 39.0002 20.6853 39.0002 21.0103C39.0002 21.4978 38.8295 21.8878 38.4883 22.1803C38.147 22.4728 37.7652 22.5703 37.3427 22.4728C36.3027 22.2128 35.482 21.8228 34.8808 21.3028C34.2795 20.7828 33.4427 20.5228 32.3702 20.5228C31.0377 20.5228 30.087 20.8803 29.5183 21.5953C28.9495 22.3103 27.7877 22.6678 26.0327 22.6678C24.2777 22.6678 23.0833 22.3103 22.4495 21.5953C21.8158 20.8803 20.8327 20.5228 19.5002 20.5228C18.1677 20.5228 17.1845 20.8803 16.5508 21.5953C15.917 22.3103 14.7227 22.6678 12.9677 22.6678C11.2127 22.6678 10.0508 22.3103 9.48203 21.5953C8.91328 20.8803 7.96265 20.5228 6.63015 20.5228C5.55765 20.5228 4.72078 20.7828 4.11953 21.3028C3.51828 21.8228 2.69765 22.2128 1.65765 22.4728C1.23515 22.5703 0.853278 22.4728 0.512028 22.1803C0.170778 21.8878 0.000152588 21.4978 0.000152588 21.0103ZM2.92515 35.4403C2.14515 35.4403 1.46265 35.1478 0.877653 34.5628C0.292653 33.9778 0.000152588 33.2953 0.000152588 32.5153V29.2003C0.000152588 28.3878 0.284528 27.6972 0.853278 27.1285C1.42203 26.5597 2.11265 26.2753 2.92515 26.2753H36.0752C36.8877 26.2753 37.5783 26.5597 38.147 27.1285C38.7158 27.6972 39.0002 28.3878 39.0002 29.2003V32.5153C39.0002 33.2953 38.7077 33.9778 38.1227 34.5628C37.5377 35.1478 36.8552 35.4403 36.0752 35.4403H2.92515ZM2.92515 32.5153H36.0752V29.2003H2.92515V32.5153Z" fill="#1A1A1A"/>
                        </svg>
                        <div style={{marginTop:'8px'}}>
                        Meals
                        </div>
                    </div>

                    <div className={styles.singleDetail}>
                        <svg style={{marginRight:'12px'}}  width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.95826 35.0002C1.40348 35.0002 0.938442 34.8126 0.56315 34.4373C0.187859 34.062 0.000213623 33.597 0.000213623 33.0422V17.6716L4.16105 5.1401C4.25896 4.68323 4.51187 4.32425 4.91979 4.06318C5.32772 3.80211 5.77644 3.67157 6.26595 3.67157H12.4827V1.46878C12.4827 1.04453 12.6214 0.693717 12.8988 0.416328C13.1762 0.138939 13.527 0.000244141 13.9513 0.000244141H21.3918C21.8161 0.000244141 22.1669 0.138939 22.4443 0.416328C22.7217 0.693717 22.8604 1.04453 22.8604 1.46878V3.67157H28.9792C29.4687 3.67157 29.9175 3.80211 30.3254 4.06318C30.7333 4.32425 30.9862 4.68323 31.0841 5.1401L35.245 17.6716V33.0422C35.245 33.597 35.0573 34.062 34.682 34.4373C34.3067 34.8126 33.8417 35.0002 33.2869 35.0002C32.7321 35.0002 32.259 34.8044 31.8673 34.4128C31.4757 34.0212 31.2799 33.548 31.2799 32.9933V30.8884H3.9163V33.0422C3.9163 33.597 3.72865 34.062 3.35336 34.4373C2.97807 34.8126 2.51303 35.0002 1.95826 35.0002ZM4.06315 14.7345H31.182L28.4897 6.60864H6.75546L4.06315 14.7345ZM8.12609 25.5037C8.87667 25.5037 9.50488 25.2427 10.0107 24.7205C10.5165 24.1984 10.7694 23.5783 10.7694 22.8604C10.7694 22.1098 10.5165 21.4653 10.0107 20.9268C9.50488 20.3884 8.87667 20.1191 8.12609 20.1191C7.3755 20.1191 6.73098 20.3884 6.19252 20.9268C5.65406 21.4653 5.38483 22.1098 5.38483 22.8604C5.38483 23.611 5.65406 24.2392 6.19252 24.745C6.73098 25.2508 7.3755 25.5037 8.12609 25.5037ZM27.168 25.5037C27.9186 25.5037 28.5631 25.2427 29.1016 24.7205C29.6401 24.1984 29.9093 23.5783 29.9093 22.8604C29.9093 22.1098 29.6401 21.4653 29.1016 20.9268C28.5631 20.3884 27.9186 20.1191 27.168 20.1191C26.4175 20.1191 25.7893 20.3884 25.2834 20.9268C24.7776 21.4653 24.5247 22.1098 24.5247 22.8604C24.5247 23.611 24.7858 24.2392 25.3079 24.745C25.83 25.2508 26.4501 25.5037 27.168 25.5037ZM2.93728 27.9513H32.3079V17.6716H2.93728V27.9513Z" fill="#1A1A1A"/>
                        </svg>
                        <div style={{marginTop:'8px'}}>
                        Cabs
                        </div>
                        
                    </div>

                    <div className={styles.singleDetail}>
                        <svg style={{marginRight:'12px',marginTop:'2px'}}  width="40" height="22" viewBox="0 0 41 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.60522 23.2192C0.987885 23.2192 0.549255 22.9511 0.289326 22.415C0.0293969 21.8789 0.0781335 21.3672 0.435536 20.8798L9.20814 9.18301C9.50056 8.79311 9.89046 8.59816 10.3778 8.59816C10.8652 8.59816 11.2551 8.79311 11.5475 9.18301L19.8815 20.295H35.7209L24.0241 4.74796L17.932 12.8383L16.08 10.4014L22.8544 1.38513C23.1468 0.99524 23.5367 0.800293 24.0241 0.800293C24.5115 0.800293 24.9014 0.99524 25.1938 1.38513L39.8148 20.8798C40.1722 21.3672 40.2209 21.8789 39.961 22.415C39.7011 22.9511 39.2624 23.2192 38.6451 23.2192H1.60522ZM4.52942 20.295H16.2262L10.3778 12.4971L4.52942 20.295Z" fill="#1A1A1A"/>
                        </svg>
                        <div style={{marginTop:'4px'}}>
                        SIGHTSEEING
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <div className={styles.firstBreak}></div>

        <div className={styles.tripDescription}>
                <div className={styles.styleHeading}>
                    <div className={styles.heading}> TRIP - DESCRIPTION</div>
                </div>

                <div className={styles.itenary}>
                    <div className={styles.leftSpace}></div>
                    <div className={styles.rightSpace}>

                        {
                            hotels &&
                            hotels.map((item,idx)=>{
                                return(

                                    item.hotelname === "blank" ? <div div className={styles.hotelBreak}></div>

                                    :

                                    <div className={styles.singleItenaryHotel}>

                                        <div className={styles.hotelInfo}>
                                            <div className={styles.HotelHeading}>Hotel - 1</div>
                                            <div className={styles.lightText}> 
                                                NAME - Sikkim Continental, Gangtok.
                                            </div>
                                            <div className={styles.lightText}> 
                                                STAR RATING - 3 Stars
                                            </div>
                                            <div className={styles.lightText}> 
                                                ROOM TYPE - Executive
                                            </div>
                                            <div className={styles.lightText}> 
                                                MEAL PLAN - MAP
                                            </div>
                                            <div className={styles.lightText}> 
                                                NIGHTS - 2
                                            </div>
                                            

                                        </div>
                                        <div className={styles.hotelInfo}>
                                            <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                            <div className={styles.lightText}> 
                                                RAVANGLA - Private
                                            </div>
                                            <div className={styles.lightText}> 
                                                NAMCHI SIGHTSEEING - Private
                                            </div>

                                        </div>

                                    </div>
                                )
                            })
                        }

                        

                        {/* <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div>

                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div>

                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div>

                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div>

                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div>
                        
                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>Hotel - 1</div>
                                <div className={styles.lightText}> 
                                    NAME - Sikkim Continental, Gangtok.
                                </div>
                                <div className={styles.lightText}> 
                                    STAR RATING - 3 Stars
                                </div>
                                <div className={styles.lightText}> 
                                    ROOM TYPE - Executive
                                </div>
                                <div className={styles.lightText}> 
                                    MEAL PLAN - MAP
                                </div>
                                <div className={styles.lightText}> 
                                    NIGHTS - 2
                                </div>
                                

                            </div>
                            <div className={styles.hotelInfo}>
                                <div className={styles.HotelHeading}>SIGHTSEEING</div>
                                <div className={styles.lightText}> 
                                    RAVANGLA - Private
                                </div>
                                <div className={styles.lightText}> 
                                    NAMCHI SIGHTSEEING - Private
                                </div>

                            </div>

                        </div> */}

                      

                    </div>

                </div>

                
                
        </div>

            <div className={styles.tripDescriptionActivity}>
                <div className={styles.styleHeading}>
                    <div className={styles.heading}> DAY-WISE ITINERARY</div>
                </div>

                <div className={styles.itenary}>
                    <div className={styles.leftSpace}></div>
                    <div className={styles.rightSpace}>


                        

                        {
                            activity &&
                            activity.map((item,idx)=>{
                                return(
                                    <>
                                    {
                                        item.hotelname === "blank" ? <div div className={styles.hotelBreak}></div>

                                        :

                                        <div className={styles.singleItenaryHotel}>
                                        <div className={styles.hotelInfo2}>
                                            <div className={styles.lightTextHEAD}>DAY</div>
                                            <div className={styles.HotelHeading2}>01</div>
                                            <div className={styles.lightTextCONT}> 
                                            Arrival and Transfer to Gangtok Hotel.
                                            </div>
                                            
                                            

                                        </div>
                                        <div className={styles.hotelInfo3}>
                                            <ul style={{padding:'0px'}}>
                                        <li className={styles.lightText3}> 
                                        Pick up and a ride to Gangtok from the Airport/Railway Station.
                                            </li>
                                            <li className={styles.lightText3}> 
                                        Pick up and a ride to Gangtok from the Airport/Railway Station.
                                            </li>
                                            <li className={styles.lightText3}> 
                                        Pick up and a ride to Gangtok from the Airport/Railway Station.
                                            </li>
                                        <li className={styles.lightText3}> 
                                            
                                        Pick up and a ride to Gangtok from the Airport/Railway Station.
                                            </li>
                                            </ul>
                                        

                                        </div>

                                    </div>

                                    }</>
                                   
                                )
                            })
                        }


                        {/* <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo2}>
                                <div className={styles.lightTextHEAD}>DAY</div>
                                <div className={styles.HotelHeading2}>01</div>
                                <div className={styles.lightTextCONT}> 
                                Arrival and Transfer to Gangtok Hotel.
                                </div>
                                
                                

                            </div>
                            <div className={styles.hotelInfo3}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText3}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                </ul>
                               

                            </div>

                        </div>


                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo2}>
                                <div className={styles.lightTextHEAD}>DAY</div>
                                <div className={styles.HotelHeading2}>02</div>
                                <div className={styles.lightTextCONT}> 
                                Arrival and Transfer to Gangtok Hotel.
                                </div>
                                
                                

                            </div>
                            <div className={styles.hotelInfo3}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText3}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                </ul>
                               

                            </div>

                        </div>


                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo2}>
                                <div className={styles.lightTextHEAD}>DAY</div>
                                <div className={styles.HotelHeading2}>03</div>
                                <div className={styles.lightTextCONT}> 
                                Arrival and Transfer to Gangtok Hotel.
                                </div>
                                
                                

                            </div>
                            <div className={styles.hotelInfo3}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText3}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                </ul>
                               

                            </div>

                        </div>


                        <div className={styles.singleItenary}>
                            <div className={styles.hotelInfo2}>
                                <div className={styles.lightTextHEAD}>DAY</div>
                                <div className={styles.HotelHeading2}>04</div>
                                <div className={styles.lightTextCONT}> 
                                Arrival and Transfer to Gangtok Hotel.
                                </div>
                                
                                

                            </div>
                            <div className={styles.hotelInfo3}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText3}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText3}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                </ul>
                               

                            </div>

                        </div> */}





                    </div>

                </div>

                
                
            </div>

            <div className={styles.tripDescription}>
                <div className={styles.styleHeading}>
                    <div className={styles.heading}> INCLUSIONS </div>
                </div>

                <div className={styles.itenary}>
                    <div className={styles.leftSpace}></div>
                    <div className={styles.rightSpace}>


                        <div className={styles.singleItenary}>
                           
                            <div className={styles.hotelInfo4}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText4}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>

                                <li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li>
                                </ul>
                               

                            </div>

                        </div>



                    </div>

                </div>

                
                
            </div>

            <div className={styles.tripDescription}>
                <div className={styles.styleHeading}>
                    <div className={styles.heading}> EXCLUSIONS </div>
                </div>

                <div className={styles.itenary}>
                    <div className={styles.leftSpace}></div>
                    <div className={styles.rightSpace}>


                        <div className={styles.singleItenary}>
                           
                            <div className={styles.hotelInfo4}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            <li className={styles.lightText4}> 
                                
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>

                                <li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li><li className={styles.lightText4}> 
                                
                                Pick up and a ride to Gangtok from the Airport/Railway Station.
                                    </li>
                                </ul>
                               

                            </div>

                        </div>



                    </div>

                </div>

                
                
            </div>

            <div className={styles.tripDescription}>
                <div className={styles.styleHeading}>
                    <div className={styles.heading2}> TERMS AND CONDITIONS </div>
                </div>

                <div className={styles.itenary}>
                    <div className={styles.leftSpace}></div>
                    <div className={styles.rightSpace}>


                        <div className={styles.singleItenary}>
                           
                            <div className={styles.hotelInfo4}>
                                <ul style={{padding:'0px'}}>
                            <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                                <li className={styles.lightText4}> 
                            Pick up and a ride to Gangtok from the Airport/Railway Station.
                                </li>
                            
                                </ul>
                               

                            </div>

                        </div>



                    </div>

                </div>

                
                
            </div>


    <div className={styles.endTrip}>END OF TRIP</div>


    
    </div>
  )
}
