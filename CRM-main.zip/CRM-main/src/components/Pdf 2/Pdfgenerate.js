import React, { useRef, useState } from 'react'
import { jsPDF } from "jspdf";
import Pdfstyle from './Pdfstyle';
import Flatnavbar from '../Navbar/Flatnavbar';
import Footer from '../footer/Footer';
import html2canvas from 'html2canvas';
import {
    Canvg,
    presets
  } from 'canvg'
export default function Pdfgenerate() {

    const certificateTemplateRef = useRef(null)
    const preset = presets.offscreen()
    const [showLoader, setLoader] = useState(false);

    const handleGeneratePdf = () => {

      if(hotels.length%6 !== 0){
        const diff = 6 - (hotels.length%6);
        let arr = hotels;

        for (let index = 0; index < diff; index++) {
          arr.push({hotelname:'blank'})
        }
        setHotels(arr)
      }

      if(activity.length < 6){
        const diff = 6 - hotels.length;
        let arr = hotels;

        for (let index = 0; index < diff; index++) {
          arr.push({hotelname:'blank'})
        }
        setActivity(arr)
      }

      

      
      window.scrollTo(0, 0);
      setTimeout(() => {
          setTimeout(() => {
              setLoader(true);
          }, 100);
          html2canvas(certificateTemplateRef.current).then(canvas => {
              const imgData = canvas.toDataURL('image/png');
              const imgWidth = 190;
              const pageHeight = 290;
              const imgHeight = (canvas.height * imgWidth) / canvas.width;
              let heightLeft = imgHeight;
              const doc = new jsPDF('pt', 'mm');
              let position = 0;
              doc.addImage(imgData, 'PNG', 10, 0, imgWidth, imgHeight + 25);
              heightLeft -= pageHeight;
              while (heightLeft >= 0) {
                  position = heightLeft - imgHeight;
                  doc.addPage();
                  doc.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight + 25);
                  heightLeft -= pageHeight;
              }
              doc.save('download.pdf');
              setLoader(false);
          });
      }, 1000);
    };


    const [hotels, setHotels] = useState([{hotelName:'mon'},{hotelName:'mon'},{hotelName:'mon'}]);
    const [activity, setActivity] = useState([{hotelName:'mon'},{hotelName:'mon'},{hotelName:'mon'}]);




  return (
    <div>
        <div
      style={{
        display: "flex",
        alignItems: "center",
        flexDirection: "column"
      }}
    >
      <button
        style={{
          margin: "50px",
          padding: "10px",
          backgroundColor: "black",
          color: "white",
          fontFamily: "Anton",
          fontSize: "1.2rem",
          textTransform: "uppercase",
          letterSpacing: "0.1rem",
          cursor: "pointer",
          width: "200px"
        }}
        onClick={handleGeneratePdf}
      >
        Generate Pdf
      </button>
      <div ref={certificateTemplateRef}>
        <Pdfstyle setHotels={setHotels} hotels={hotels} activity={activity} setActivity={setActivity}/>
        {/* <ContentTemplate /> */}
      </div>
    </div>
    </div>
  )
}
