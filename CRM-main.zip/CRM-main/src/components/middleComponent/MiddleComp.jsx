import React, { useRef, useState } from "react";
// import { FaBed } from "react-icons/fa";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import "./Middlecompo.css";

const MiddleComp = ({ days, data }) => {
  const day = parseInt(days);
  const arr = Array.from({ length: day - 1 }, (value, index) => index);

  const [hotel, setHotel] = useState({
    nights: "",
    hotelname: "",
    cityname: "",
    category: "",
    roomtype: "",
    comments: "",
  });
  console.log("hotel:", hotel);

  // const [showH, setShowH] = useState(true);
  // const open = () => {
  //   setShowH(!showH);
  // };

  const option = useRef(null);
  const [value, setValue] = useState("");
  const [expanded, setExpanded] = useState(false);

  const handleChange = (event) => {
    setValue(event.target.value);
  };

  const showCheckboxes = () => {
    if (!expanded) {
      option.current.style.display = "flex";
      setExpanded(true);
    } else {
      option.current.style.display = "none";
      setExpanded(false);
    }
  };

  document.addEventListener("mouseup", function (event) {
    var pol = document.getElementById("checkboxes");
    if (event.target !== pol && event.target.parentNode !== pol) {
      pol.style.display = "none";
      setExpanded(false);
    }
  });

  return (
    <div>
      <div className="hotel">
        {/* {showH && ( */}
        <>
          <div className="quotation">
            <form className="hotelD">
              <div className="tnight">
                <div className="nii">
                  <label htmlFor="hotelNight"> Nights</label>
                </div>
                <div>
                  <div className="afname">
                    <div className="selectBox" onClick={showCheckboxes}>
                      <div className="valuediv">{value ? value : "Select"}</div>
                      {expanded ? (
                        <div className="arrowicons">
                          <IoIosArrowUp />
                        </div>
                      ) : (
                        <div className="arrowicons">
                          <IoIosArrowDown />
                        </div>
                      )}
                    </div>
                    <div id="checkboxes" ref={option}>
                      {arr.map((item, key) => (
                        <div className="checkboxdiv1">
                          <input
                            type="checkbox"
                            id="one"
                            value={key + 1}
                            name=""
                            onChange={handleChange}
                          />
                          <label htmlFor="one">{item + 1}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="day">
                  <label
                    hmtmlFor="days"
                    onClick={() => {
                      console.log(data);
                    }}
                  >
                    Hotel Name
                  </label>
                  <br />
                </div>
                <div className="dayInput">
                  <input
                    className="hn"
                    placeholder="enter hotel name"
                    onChange={(e) => {
                      data.hotelname = e.target.value;
                    }}
                  />
                  <br />
                </div>
              </div>
              <div>
                <div className="day">
                  <label hmtmlFor="days">City</label>
                  <br />
                </div>
                <div className="dayInput">
                  <input
                    type="text"
                    id="cityname"
                    className="cn"
                    name="day"
                    placeholder="enter city name"
                    onChange={(e) => {
                      data.cityname = e.target.value;
                    }}
                  />
                  <br />
                </div>
              </div>
              <div>
                <div className="day">
                  <label hmtmlFor="days">Category</label>
                  <br />
                </div>
                <div className="dayInput">
                  <input
                    type="text"
                    id="category"
                    className="category"
                    name="day"
                    placeholder="enter cateogry"
                    onChange={(e) => {
                      data.category = e.target.value;
                    }}
                  />
                  <br />
                </div>
              </div>
              <div>
                <div className="day">
                  <label hmtmlFor="days">Room Type</label>
                  <br />
                </div>
                <div className="dayInput">
                  <select
                    onChange={(e) => {
                      data.roomtype = e.target.value;
                    }}
                    name="cars"
                    id="roomtype"
                    className="rt"
                  >
                    <option value="select">Select</option>
                    <option value="single">Single</option>
                    <option value="double">Double</option>
                    <option value="deluxe">Deluxe</option>
                    <option value="presidential">Presidential</option>
                  </select>
                  <br />
                </div>
              </div>
            </form>
            <div>
              <div className="day">
                <label hmtmlFor="days">Comments</label>
                <br />
              </div>
              <div className="dayInput">
                <textarea
                  type="text"
                  id="comments"
                  className="cmnt"
                  name="day"
                  placeholder="extra services??"
                  onChange={(e) => {
                    data.category = e.target.value;
                  }}
                />
                <br />
              </div>
            </div>
            {/* <hr /> */}
          </div>
        </>
        {/* )} */}
      </div>
    </div>
  );
};

export default MiddleComp;
