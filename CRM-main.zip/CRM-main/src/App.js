import "./App.css";
import { Routes, Route, Navigate, Link, useNavigate } from "react-router-dom";
import Basicdetails from "./components/basicDetails/Basicdetails";
import Login from "./pages/Login";
import Signuppage from "./pages/Signup";
// import Client from "./pages/Client";
import Dashboard from "./components/Dashboard/Dashboard";
import { CookiesProvider } from "react-cookie";
import Navbar from "./components/navbar/Navbar";
import Home from "./components/home/Home";
import Forgetpassword from "./components/Forgetpassword/Forgetpassword";
import Resetpassword from "./components/Resetpassword/Resetpassword";
import Allquote from "./components/Allquote/Allquote";
import Samequote from "./components/Samequote/Samequote";
// const [isLoading, setIsLoading] = useState(true);

// useEffect(() => {
//   const userInfo = GET_USER_FROM_LS;
//   if (router.pathname !== "/login" && !userInfo) {
//     router.push("/login");
//   } else {
//     setIsLoading(false);
//   }
// }, []);

// // if (isLoading) {
// //   return <YourLoadingComponent />;
// // }

function App() {
  return (
    <>
      <CookiesProvider>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signuppage />} />
          <Route path="/Basicdetail/:id" element={<Basicdetails />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/resetpassword/:id" element={<Resetpassword />} />
          <Route path="/forgetpassword" element={<Forgetpassword />} />
          <Route path="/allquote/:id" element={<Allquote />} />
          <Route path="/samequote/:id" element={<Samequote />} />
        </Routes>
      </CookiesProvider>
    </>
  );
}

export default App;
