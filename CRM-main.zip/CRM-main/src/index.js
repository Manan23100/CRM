// import 'bootstrap/dist/css/bootstrap.min.css';
//import 'bootstrap/dist/js/bootstrap.bundle.min';
// eslint-disable-next-line
// import $ from 'jquery';
// eslint-disable-next-line
// import Popper from 'popper.js';
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { BrowserRouter } from "react-router-dom";
import Usercheck from "./pages/Usercontext";
import "react-datepicker/dist/react-datepicker.css";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
       <Usercheck> 
        <App />
       </Usercheck> 
    </BrowserRouter>
  </React.StrictMode>
);
