import express from "express";
import {
  logIn,
  register,
  getusers,
  filter,
  getclient,
  getuserdatafromtoken,
  updatepassword,
} from "../controllers/auth.controller.js";

const router = express.Router();

router.post("/register", register);
router.post("/login", logIn);
router.get("/alluser", getusers);
router.post("/allclient", getclient);
router.post("/filter", filter);
router.post("/tokenverify", getuserdatafromtoken);
router.post("/updatepassword", updatepassword);


export default router;
