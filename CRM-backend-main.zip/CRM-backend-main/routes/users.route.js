import express from "express";
import {
  deleteUser,
  getUser,
  getUsers,
  updateUser,
  getuserusingemail,
} from "../controllers/user.controller.js";
import { verifyAdmin, verifyUser, verifyToken } from "../utils/verifyToken.util.js";

const router = express.Router();

//UPDATE
router.put("/:id",verifyUser, updateUser);

//DELETE
router.delete("/:id", verifyUser , deleteUser);

//GET
router.get("/:id", verifyUser , getUser);

//GET ALL
router.get("/", getUsers);

//Get user Data using mail
router.post("/getuserusingemail", getuserusingemail);


export default router;
