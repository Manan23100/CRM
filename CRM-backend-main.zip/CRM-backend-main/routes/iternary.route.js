import express from "express";
import {
  addIternary,
  getallitenaryforclient,
  getitenaryforclient,
  samequote,
} from "../controllers/iternary.controller.js";
const router = express.Router();

router.post("/addIternary", addIternary);

router.get("/allquote/:id", getallitenaryforclient);

router.post("/getitenary", getitenaryforclient);

router.get("/samequote", samequote);

export default router;
