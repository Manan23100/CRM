//utils file sendEmail
// const nodemailer = require("nodemailer");
import nodemailer from "nodemailer";
// var smtpTransport = require('nodemailer-smtp-transport');
const sendEmail = async (subject, message, send_to) => {
  const transporter = await nodemailer.createTransport({
    service: "gmail",

    auth: {
      user: "dev.holidayscrowd@gmail.com",
      pass: "parkrhuxcdcrkqiw",
    },
    tls: {
      rejectUnauthorized: false,
    },
  });

  const options = {
    from: "dev.holidayscrowd@gmail.com",
    to: send_to,
    replyto: "dev.holidayscrowd@gmail.com",
    subject: subject,
    html: message,
  };

  await transporter.sendMail(options, function (err, info) {
    if (err) {
      console.log(err);
    } else {
      console.log(info, "info");
    }
  });
};

export default sendEmail;
