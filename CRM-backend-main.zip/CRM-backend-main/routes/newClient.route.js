import express from "express";
import {
  registerClient,
  getClient,
  totalSale,
  deleteCleint,
  getuserdetail,
  updateclient,
} from "../controllers/newClient.controller.js";

const router = express.Router();

router.post("/addClient", registerClient)

router.get("/", getClient)

router.get("/totalSale",totalSale);

router.post("/getuserdetail", getuserdetail)

router.post("/deletebyid", deleteCleint);

router.put("/updateclient", updateclient);


export default router
