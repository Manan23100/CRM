import request from "supertest";
import { TESTING_URL } from "./Alltesturl";
// const { TESTING_URL } = require("./Alltesturl");
import app from "../index";
// const app = require("../index");

describe("Testing LOGIN API", () => {
  it("should clear all test cases", async () => {
    const res = await request(app).post(`${TESTING_URL}/api/auth/login`).send({
      email: "singhaldilip66@gmail.com",
      password: "9602675361@Aa",
    });
    expect(res.statusCode).toEqual(200);
  });
});
