import mongoose, { trusted } from "mongoose";
const ClientSchema = new mongoose.Schema(
  {
    userid: {
      type: String,
      required: true,
    },
    tripId: {
      type: Number,
      required: true,
    },
    clientname: {
      type: String,
      required: true,
    },
    clientemail: {
      type: String,
      required: true,
      unique: true,
    },
    contactNumber: {
      type: Number,
      required: true,
    },
    destination: {
      type: String,
      required: true,
    },
    startdate: {
      type: String,
      required: true,
    },
    days: {
      type: Number,
      required: true,
    },
    adults: {
      type: Number,
      required: true,
    },
    children: {
      type: Number,
    },
    comments: {
      type: String,
    },
    Status: {
      type: String,
    },

    iternary: [
      {
        type: mongoose.Types.ObjectId,
        ref: "Iternary",
      },
    ],
  },
  { timestamps: true }
);

export default mongoose.model("Client", ClientSchema);
