import mongoose from "mongoose";

const IternarySchema = new mongoose.Schema(
  {
    clientid: {
      type: mongoose.Types.ObjectId,
      ref: "Client",
    },
    clientname: {
      type: String,
      required: true,
    },
    destination: {
      type: String,
      required: true,
    },
    startDate: {
      type: String,
      required: true,
    },
    endDate: {
      type: String,
      required: true,
    },
    days: {
      type: Number,
      required: true,
    },
    nights: {
      type: Number,
      required: true,
    },
    adults: {
      type: Number,
      required: true,
    },
    children: {
      type: Number,
      required: true,
    },
    flightcost: {
      type: Number,
      required: true,
    },
    Status: {
      type: String,
    },
    visacost: {
      type: Number,
      required: true,
    },
    packagecost: {
      type: Number,
      required: true,
    },
    markup: {
      type: Number,
      required: true,
    },
    gst: {
      type: Number,
      required: true,
    },
    finalprice: {
      type: Number,
      required: true,
    },
    hotels: [
      {
        hnights: {
          type: String,
          required: true,
        },
        hotelname: {
          type: String,
          required: true,
        },
        cityname: {
          type: String,
          required: true,
        },
        hotelcateogry: {
          type: String,
          required: true,
        },
        roomtype: {
          type: String,
          required: true,
        },
        comments: {
          type: String,
        },
      },
    ],
    breakfast: {
      type: Boolean,
    },
    lunch: {
      type: Boolean,
    },
    dinner: {
      type: Boolean,
    },
    showComment: {
      type: String,
    },

    flight: {
      type: Boolean,
    },
    showF: {
      type: String,
    },
    train: {
      type: Boolean,
    },
    showT: {
      type: String,
    },
    bus: {
      type: Boolean,
    },
    showB: {
      type: String,
    },

    suvCab: {
      type: Boolean,
    },
    smallCab: {
      type: Boolean,
    },
    sedanCab: {
      type: Boolean,
    },
    acCab: {
      type: Boolean,
    },
    nonAcCab: {
      type: Boolean,
    },
    showComment2: {
      type: String,
    },

    eveningCruise: {
      type: Boolean,
    },
    jeepSafari: {
      type: Boolean,
    },
    elephantSafari: {
      type: Boolean,
    },
    showComment3: {
      type: String,
    },

    homeStay: {
      type: Boolean,
    },
    budgetHotel: {
      type: Boolean,
    },
    threeStarHotel: {
      type: Boolean,
    },
    fourStarHotel: {
      type: Boolean,
    },
    fiveStarHotel: {
      type: Boolean,
    },
    sharingHouseboat: {
      type: Boolean,
    },
    pvtHouseboat: {
      type: Boolean,
    },
    budgetHouseboat: {
      type: Boolean,
    },
    premiumHouseboat: {
      type: Boolean,
    },
    luxuryHouseboat: {
      type: Boolean,
    },
    showComment4: {
      type: String,
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    terms: {
      type: String,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Iternary", IternarySchema);
