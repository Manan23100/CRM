import Iternary from "../models/iternary.model.js";
import Client from "../models/Client.model.js";

export const addIternary = async (req, res) => {
  try {
    const {
      clientid,
      clientname,
      destination,
      startDate,
      endDate,
      days,
      nights,
      adults,
      children,
      flightcost,
      visacost,
      packagecost,
      markup,
      Status,
      gst,
      finalprice,
      hotels,
      breakfast,
      lunch,
      dinner,
      showComment,
      flight,
      showF,
      train,
      showT,
      bus,
      showB,
      suvCab,
      smallCab,
      sedanCab,
      acCab,
      nonAcCab,
      showComment2,
      eveningCruise,
      jeepSafari,
      elephantSafari,
      showComment3,
      homeStay,
      budgetHotel,
      threeStarHotel,
      fourStarHotel,
      fiveStarHotel,
      sharingHouseboa,
      pvtHouseboat,
      budgetHouseboat,
      premiumHouseboat,
      luxuryHouseboat,
      showComment4,
      title,
      description,
      terms,
    } = req.body;

    const addItern = new Iternary({
      clientid,
      clientname,
      destination,
      startDate,
      Status,
      endDate,
      days,
      nights,
      adults,
      children,
      flightcost,
      visacost,
      packagecost,
      markup,
      gst,
      finalprice,
      hotels,
      breakfast,
      lunch,
      dinner,
      showComment,
      flight,
      showF,
      train,
      showT,
      bus,
      showB,
      suvCab,
      smallCab,
      sedanCab,
      acCab,
      nonAcCab,
      showComment2,
      eveningCruise,
      jeepSafari,
      elephantSafari,
      showComment3,
      homeStay,
      budgetHotel,
      threeStarHotel,
      fourStarHotel,
      fiveStarHotel,
      sharingHouseboa,
      pvtHouseboat,
      budgetHouseboat,
      premiumHouseboat,
      luxuryHouseboat,
      showComment4,
      title,
      description,
      terms,
    });

    const iternaryid = await addItern.save();

    const updateClient = await Client.findByIdAndUpdate(clientid, {
      $push: {
        iternary: iternaryid._id,
      },
    });
    return res.status(201).json({
      status: "Iternary has been created.",
      addItern,
      updateClient,
    });
  } catch (err) {
    next(err);
  }
};

export const getallitenaryforclient = async (req, res) => {
  const { id } = req.params;

  console.log(id);

  const getall = await Iternary.find({ clientid: id });

  if (!getall) {
    return res.status(404).json({ message: "Not found" });
  }

  return res.status(200).json({ message: "User Found", getall });
};

export const getitenaryforclient = async (req, res) => {
  const { id } = req.body;
  //63e4c4b4666e2c54a2839251
  console.log(id);

  const getall = await Iternary.find({ _id: id });

  if (!getall) {
    return res.status(404).json({ message: "Not found" });
  }

  return res.status(200).json({ message: "User Found", getall });
};

export const samequote = async (req, res) => {
  try {
    const quote = await Iternary.find({});

    if (!quote) {
      return res.status(404).json({ message: "Not Found" });
    }

    return res.status(200).json({ message: "sucess", quote });
  } catch (error) {
    console.log(error, "error");

    return res.status(500).json({ message: "Internal server error" });
  }
};
