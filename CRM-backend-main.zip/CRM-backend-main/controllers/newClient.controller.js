import { deleteModel } from "mongoose";
import Client from "../models/Client.model.js";
import User from "../models/User.model.js";

export const registerClient = async (req, res, next) => {
  try {
    const { email } = req.body;
    console.log(req.body);

    const startdate = req.body.clientDetails.startDate.split("T")[0];
    const userdata = await User.findOne({ email: email });

    const generateTripId = (otp_length) => {
      var digits = "0123456789";
      let OTP = "";
      for (let i = 0; i < otp_length; i++) {
        OTP += digits[Math.floor(Math.random() * 10)];
      }
      return OTP;
    };
    if (!userdata) {
      return res.status(400).json({ message: "user not found" });
    }

    const tripId = await generateTripId(4);

    console.log(tripId, "tripId");

    const checkingTripId = await Client.findOne({ tripId: tripId });

    console.log(checkingTripId, "okkokok");

    if (checkingTripId) {
      tripId = await generateTripId(4);
      console.log(tripId, "tripId");
      const useridi = userdata._id;
      const newClienti = new Client({
        userid: useridi,
        tripId,
        clientname: req.body.clientDetails.clientname,
        clientemail: req.body.clientDetails.clientemail,
        contactNumber: req.body.clientDetails.contactNumber,
        destination: req.body.clientDetails.destination,
        startdate: startdate,
        days: req.body.clientDetails.days,
        adults: req.body.clientDetails.adults,
        children: req.body.clientDetails.children,
        Status: "New Lead",
        comments: req.body.clientDetails.comments,
      });

      await newClienti.save();
      res.status(201).json({
        status: "Client has been created.",
        newClienti,
      });
    }

    const userid = userdata._id;
    const newClient = new Client({
      userid: userid,
      tripId,
      clientname: req.body.clientDetails.clientname,
      clientemail: req.body.clientDetails.clientemail,
      contactNumber: req.body.clientDetails.contactNumber,
      destination: req.body.clientDetails.destination,
      startdate: startdate,
      days: req.body.clientDetails.days,
      adults: req.body.clientDetails.adults,
      children: req.body.clientDetails.children,
      Status: "New Lead",
      comments: req.body.clientDetails.comments,
    });
    console.log(newClient, "newClient");
    await newClient.save();

    res.status(201).json({
      status: "Client has been created.",
      newClient,
    });
  } catch (err) {
    next(err);
  }
};

export const totalSale = async (req, res, next) => {
  try {
    const clientdata = await Client.find({
      $or: [{ Status: "Converted" }, { Status: "Past-Trip" }],
    });

    if (clientdata) {
      const size = clientdata.size();
      return res.status(200).json({ size, message: "total sale" });
    }
  } catch (error) {
    console.log(error, "error from TotalSale");
  }
};

export const getClient = async (req, res, next) => {
  try {
    const { email } = req.body;

    const userdata = await User.findOne({ email: email });
    if (!userdata) {
      return res.status(400).json({ message: "user not found" });
    }
    console.log(userdata);
    // if (!userdata) {
    //   return res.status(400).json({ message: "user not found" });
    // }

    const userid = userdata._id;
    const client = await Client.find({ userid: userid });
    res.status(200).json({
      status: "success",
      client,
    });
  } catch (err) {
    next(err);
  }
};

export const deleteCleint = async (req, res) => {
  const { id } = req.body;

  console.log(id);
  const userdelte = await Client.deleteOne({ _id: id });

  console.log(userdelte);
  if (userdelte) {
    res.status(200).json({ message: "delete succesfully" });
  }
};

export const getuserdetail = async (req, res) => {
  const { id } = req.body;

  console.log(id);
  const userdetail = await Client.findById({ _id: id });

  console.log(userdetail, "userdetail");

  if (!userdetail) {
    return res.status(404).json({ message: "Not Found" });
  }

  return res.status(200).json({ message: "user Find", userdetail });
};

export const updateclient = async (req, res) => {
  try {
    const { id, basicDetails, Status } = req.body;

    console.log(req.body, "ClientUpdate");

    const Clientupdate = await Client.findByIdAndUpdate(
      { _id: id },
      {
        $set: {
          clientname: basicDetails.name,
          destination: basicDetails.destination,
          startdate: basicDetails.startDate.split("T")[0],
          days: basicDetails.days,
          adults: basicDetails.adults,
          children: basicDetails.children,
          nights: basicDetails.nights,
          Status: Status,
        },
      }
    );

    return res
      .status(200)
      .json({ message: "Update Sucessfully", Clientupdate });
  } catch (error) {
    console.log(error);

    res.status(500).json({ message: "internal server error" });
  }
};
