import User from "../models/User.model.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import client from "../models/Client.model.js";
import { createError } from "../utils/error.util.js";

export const register = async (req, res, next) => {
  try {
    const { email } = req.body;
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.password, salt);

    const userFind = User.findOne({ email: email });

    // if(userFind){
    //   return res.status(404).json({message:"User email already exists"})
    // }

    const newUser = new User({
      username: req.body.username.toUpperCase(),
      email: req.body.email,
      password: hash,
    });

    await newUser.save();

    res.status(201).json({
      status: "User has been created.",
      newUser,
    });
  } catch (err) {
    next(err);
  }
};

export const updatepassword = async (req, res, next) => {
  try {
    const { id, pass } = req.body;

    console.log(req.body);
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(pass, salt);

    const updatepass = await User.findOneAndUpdate(
      { _id: id },
      { $set: { password: hash } }
    );

    console.log(updatepass);

    if (!updatepass) {
      res.status(404).json({ message: "User not found" });
    }
    res.status(200).json({ message: "updated succesfully" });
  } catch (error) {
    console.log(error);
  }
};

export const logIn = async (req, res, next) => {
  try {
    const user = await User.findOne({
      email: req.body.email,
    });
    if (!user) return next(createError(404, "User not found!"));

    const isPasswordCorrect = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (!isPasswordCorrect)
      return next(createError(400, "Wrong password or username"));

    const token = jwt.sign(
      { id: user._id },
      "anuraggupta9161018797777777@liveinnoida+originisIndianUpgut",
      {
        expiresIn: "24h",
      }
    );

    const { password, ...otherDetails } = user._doc;

    console.log(token, "token");
    return res
      .cookie("access_token", token, { httpOnly: true })
      .status(200)
      .json({
        status: "User has been login.",
        user,
        token,
        ...otherDetails,
      });
  } catch (err) {
    next(err);
  }
};

export const getusers = async (req, res, next) => {
  try {
    const r = await User.find((err, docs) => {
      if (!err) {
        res.status(200).json({
          data: docs,
        });
      } else {
        console.log("Failed to retrieve the Course List: " + err);
      }
    });
  } catch (error) {
    console.log(error);
  }
};

export const getuserdatafromtoken = async (req, res, next) => {
  try {
    const { Token } = req.body;
    console.log(Token);
    const verifytoken = jwt.verify(Token, process.env.JWT);
    console.log(verifytoken, "verify token");

    const usercheck = await User.findById({ _id: verifytoken.id });
    console.log(usercheck, "user");

    res.status(200).json({ usercheck });
  } catch (error) {
    console.log(error);
  }
};

export const getclient = async (req, res, next) => {
  try {
    const { email } = req.body;
    console.log(email, "here email");
    const userid = await User.findOne({ email: email });
    if (!userid) {
      return res.status(500).json({ message: "user not found" });
    }
    console.log(userid._id);
    const user_userid = userid._id;

    const r = await client.find({ userid: user_userid }).sort({ _id: -1 });

    if (!r) {
      res.status(400).json({ message: "Client Not found" });
    }
    console.log(r, "r");
    res.status(200).json({
      data: r,
    });
  } catch (error) {
    console.log(error);
  }
};

export const filter = async (req, res, next) => {
  try {
    console.log(req.body);
    const { delivered } = req.body;
    const user = await client.find({ Status: delivered });
    console.log(user);
    if (user) {
      return res.status(200).json({ user });
    } else {
      return res.status(400).json({ message: "user not found" });
    }
  } catch (error) {
    console.log(error);
  }
};
